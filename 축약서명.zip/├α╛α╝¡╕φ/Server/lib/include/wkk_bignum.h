/* 
========================================
  wkk_bignum.h 
    : big integer
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/

#ifndef __WKK_BIGNUM_H__
#define __WKK_BIGNUM_H__

#include <stddef.h>
#include <stdio.h>

#include "wkk_util.h"

/* constants */
#define WK_BIGINT_CHK(f) do { if( ( retCode = f ) != 0 ) goto end; } while( 0 )

#define WK_BIGINT_MAX_LIMBS                             10000
#define WK_BIGINT_WINDOW_SIZE                           6        /**< Maximum windows size used. */
#define WK_BIGINT_MAX_SIZE                              2048     /**< Maximum number of bytes for usable MPIs. */
#define WK_BIGINT_MAX_BITS                             ( 8 * WK_BIGINT_MAX_SIZE )    /**< Maximum number of bits for usable MPIs. */
#define WK_BIGINT_MAX_BITS_SCALE100						( 100 * WKK_BIGINT_MAX_BITS )
#define WK_LN_2_DIV_LN_10_SCALE100						332
#define WK_BIGINT_RW_BUFFER_SIZE						( ((WK_BIGINT_MAX_BITS_SCALE100 + WK_LN_2_DIV_LN_10_SCALE100 - 1) / WK_LN_2_DIV_LN_10_SCALE100) + 10 + 6 )
#define WK_DIGITSIZE										4
#define WK_BitsInDIGIT										(8*WK_DIGITSIZE)

#define WK_CHECK_BIT_D(A, k)	( 1 & ( (A)[(k)>>5] >> ((k) & (32-1)) ) )
#define WK_SetBitDIGIT(A, k)		(A)[(k)>>5] |= ((U32)1 << ((k) & (32-1)) )
#define WK_BIG_D2B(D, B)		*(U32 *)(B) = WK_ENDIAN_REVERSE_DWORD(D)
#define WK_ENDIAN_REVERSE_DWORD(dwS)	( (WK_ROTL_DWORD((dwS),  8) & 0x00ff00ff)	\
	| (WK_ROTL_DWORD((dwS), 24) & 0xff00ff00) )
#define WK_ROTL_DWORD(x, n) _lrotl((x), (n))

#define BIG_IS_ONE(a) \
	((a)->n == 1 && (a)->p[0] == 1)

#define MULADDC_INIT                    \
{                                       \
	U32 s0, s1, b0, b1;					\
	U32 r0, r1, rx, ry;					\
	b0 = ( b << biH ) >> biH;           \
	b1 = ( b >> biH );

#define MULADDC_CORE                    \
	s0 = ( *s << biH ) >> biH;          \
	s1 = ( *s >> biH ); s++;            \
	rx = s0 * b1; r0 = s0 * b0;         \
	ry = s1 * b0; r1 = s1 * b1;         \
	r1 += ( rx >> biH );                \
	r1 += ( ry >> biH );                \
	rx <<= biH; ry <<= biH;             \
	r0 += rx; r1 += (r0 < rx);          \
	r0 += ry; r1 += (r0 < ry);          \
	r0 +=  c; r1 += (r0 <  c);          \
	r0 += *d; r1 += (r0 < *d);          \
	c = r1; *(d++) = r0;

#define MULADDC_STOP                    \
}

/* structure */
typedef struct
{
	int s;              /*!<  integer sign      */
	U32 n;              /*!<  total # of limbs  */
	U32 *p;             /*!<  pointer to limbs  */
}
WK_BIGINT;

#ifdef __cplusplus
extern "C" {
#endif

void 
WK_Bigint_New( WK_BIGINT *X );

void 
WK_Bigint_Free( WK_BIGINT *X );

int 
WK_Bigint_Grow( WK_BIGINT *X, U32 nblimbs );

int 
WK_Bigint_Copy( WK_BIGINT *X, const WK_BIGINT *Y );

int 
WK_Bigint_Lset( WK_BIGINT *X, int z );

int 
WK_Bigint_Set_Bit( WK_BIGINT *X, U32 pos, U8 val );

U32 
WK_Bigint_Lsb( const WK_BIGINT *X );

U32 
WK_Bigint_Bitlen( const WK_BIGINT *X );

U32 
WK_Bigint_Size( const WK_BIGINT *X );

int 
WK_Bigint_Read_String( WK_BIGINT *X, int radix, const char *s );

int 
WK_Bigint_Write_String( const WK_BIGINT *X, int radix, char *buf, U32 buflen, U32 *olen );

int 
WK_Bigint_Read_Binary( WK_BIGINT *X, const U8 *buf, U32 buflen );

int 
WK_Bigint_Write_Binary( const WK_BIGINT *X, U8 *buf, U32 buflen );

int 
WK_Bigint_Shift_I( WK_BIGINT *X, U32 count );

int 
WK_Bigint_Shift_R( WK_BIGINT *X, U32 count );

int 
WK_Bigint_Cmp_Abs( const WK_BIGINT *X, const WK_BIGINT *Y );

int 
WK_Bigint_Cmp_Bignum( const WK_BIGINT *X, const WK_BIGINT *Y );

int 
WK_Bigint_Cmp_Int( const WK_BIGINT *X, int z );

int 
WK_Bigint_Add_Abs( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Sub_Abs( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Add_Bignum( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Sub_Bignum( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Add_Int( WK_BIGINT *X, const WK_BIGINT *A, int b );

int 
WK_Bigint_Sub_Int( WK_BIGINT *X, const WK_BIGINT *A, int b );

int 
WK_Bigint_Mul_Bignum( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Mul_Int( WK_BIGINT *X, const WK_BIGINT *A, U32 b );

int 
WK_Bigint_Div_Bignum( WK_BIGINT *Q, WK_BIGINT *R, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Div_Int( WK_BIGINT *Q, WK_BIGINT *R, const WK_BIGINT *A, int b );

int 
WK_Bigint_Mod_Bignum( WK_BIGINT *R, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Mod_Int( U32 *r, const WK_BIGINT *A, int b );

int 
WK_Bigint_Exp_Mod( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *E, const WK_BIGINT *N, WK_BIGINT *_RR );

int 
WK_Bigint_Fill_Random( WK_BIGINT *X, U32 size);

int 
WK_Bigint_Gcd( WK_BIGINT *G, const WK_BIGINT *A, const WK_BIGINT *B );

int 
WK_Bigint_Inv_Mod( WK_BIGINT *X, const WK_BIGINT *A, const WK_BIGINT *N );

int 
WK_Bigint_Is_Prime( const WK_BIGINT *X);

int 
WK_Bigint_Gen_Prime( WK_BIGINT *X, U32 nbits, int dh_flag);

int 
WK_Big_MulMod(WK_BIGINT *output, WK_BIGINT *inputA, WK_BIGINT *inputB, WK_BIGINT *mod);

int 
WK_Big_SubMod(WK_BIGINT *r, WK_BIGINT *a, WK_BIGINT *b, WK_BIGINT *m);	

int 
WK_Miller_Rabin( const WK_BIGINT *X);

#ifdef __cplusplus
}
#endif

#endif 
