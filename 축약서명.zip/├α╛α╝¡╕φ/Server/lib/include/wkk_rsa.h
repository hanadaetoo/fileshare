/* 
========================================
  wkk_rsa.h 
    : rsa algorithm
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/

#ifndef __WKK_RSA_H__
#define __WKK_RSA_H__

#include "wkk_util.h"
#include "wkk_bignum.h"

/* constants */
#define WK_RSA_PUBLIC      0
#define WK_RSA_PRIVATE     1

#define WK_RSA_PKCS_V15    0
#define WK_RSA_PKCS_V21    1

#define WK_RSA_SIGN        1
#define WK_RSA_CRYPT       2

#define WK_RSA_SALT_LEN_ANY    -1
#define WK_RSA_KEYLENGTH_BYTE	256

/* structure */

typedef struct{
	WK_BIGINT		*n;			// modulus
	WK_BIGINT		*e;			// publicExponent
} WK_RSA_PublicKey;


#ifdef __cplusplus
extern "C" {
#endif

int 
WK_RSA_Verify(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength);

int 
WK_RSA_Verify_V15(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength);

#ifdef __cplusplus
}
#endif

#endif /* rsa.h */
