/* 
========================================
   wkk_error.h 
    : errorcode define 
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/

#ifndef __WKK_ERROR_H__
#define __WKK_ERROR_H__

#define WKK_SUCCESS									0

#define WKMAIN										100
#define WKBIGNUM									200
#define WKRSA										300
#define WKSHA										400
#define WKASN1										800

#define	WKK_COMMON_ERROR_INVALID_INPUT				-10

#define	WKK_SHA256_ERROR_INVALID_INPUT				-(WKSHA+1)

#define WKK_BIGNUM_ERROR_BAD_INPUT_DATA             -(WKBIGNUM+1) 
#define WKK_BIGNUM_ERROR_INVALID_CHARACTER          -(WKBIGNUM+2) 
#define WKK_BIGNUM_ERROR_BUFFER_TOO_SMALL           -(WKBIGNUM+3)
#define WKK_BIGNUM_ERROR_NEGATIVE_VALUE             -(WKBIGNUM+4) 
#define WKK_BIGNUM_ERROR_DIVISION_BY_ZERO           -(WKBIGNUM+5) 
#define WKK_BIGNUM_ERROR_NOT_ACCEPTABLE             -(WKBIGNUM+6)
#define WKK_BIGNUM_ERROR_ALLOC_FAILED               -(WKBIGNUM+7)

#define WKK_RSA_ERROR_BAD_INPUT_DATA                -(WKRSA+1) 
#define WKK_RSA_ERROR_KEY_CHECK_FAILED              -(WKRSA+2)   
#define WKK_RSA_ERROR_PUBLIC_FAILED                 -(WKRSA+3)  
#define WKK_RSA_ERROR_VERIFY_FAILED                 -(WKRSA+4)   
#define WKK_RSA_ERROR_MEMORY_ALLOC_FAILED		    -(WKRSA+5)
#define WKK_RSA_ERROR_INVALID_DATALEN				-(WKRSA+6)
#define WKK_RSA_ERROR_INTENDED_MSG_LENGTH_TOO_SHORT -(WKRSA+7)   
#define WKK_RSA_ERROR_INVALID_SIGNATURE			    -(WKRSA+8)
#define WKK_RSA_ERROR_MODULUS_TOO_SHORT				-(WKRSA+9)


#define WKK_ASN1_ERROR_BAD_DATA					    -(WKASN1+1)
#define WKK_ASN1_ERROR_INVALID_LENGTH			    -(WKASN1+2)

#ifdef __cplusplus
extern "C" {
#endif

char * 
WK_GetErrorString(const int errorCode);

#ifdef __cplusplus
}
#endif

#endif
