/* 
========================================
  wkk_util.h 
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/

#ifndef __WKK_UTIL_H__
#define __WKK_UTIL_H__

#define U32 unsigned int
#define U8 unsigned char

#ifdef __cplusplus
extern "C" {
#endif

int 
WK_Uint32ToByte(U8 *buf, U32 a);

U32 
WK_ByteToUint32(U8 *buf);

void 
WK_Print_Hex (char *title, unsigned char *data, int len, int mod);

int 
WK_HexToBin(unsigned char *out, char *hexString);

#ifdef __cplusplus
}
#endif

#endif