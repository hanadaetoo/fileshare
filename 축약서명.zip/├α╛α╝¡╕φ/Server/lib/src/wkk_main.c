
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "wkk_error.h"
#include "wkk_rsa.h"
#include "wkk_util.h"

#define	WK_CRYPTO_VERSION					"1.0.0.0"

char *
WKK_GetVersion(void)
{
	return WK_CRYPTO_VERSION;
}

int 
WKK_HexToBin(unsigned char *out, char *hexString)
{
	return WK_HexToBin(out, hexString);
}


int 
WKK_SIgnVerify_PSS(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength)
{
	int retCode = 0;

	retCode = WK_RSA_Verify(signature, signatureLength, message, messageLength, pubKey, pubKeyLength);

	return retCode;
}

int 
WKK_SIgnVerifyHex_PSS(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, char *pubKeyHex)
{
	int retCode = 0, len;
	U8 pubKey[WK_RSA_KEYLENGTH_BYTE*2] = {0x00,};

	retCode = WK_HexToBin(pubKey, pubKeyHex);
	if (retCode < 0) {
		return retCode;
	}
	WK_Print_Hex("pubKey", pubKey, retCode, 10);

	len = retCode;
	retCode = WK_RSA_Verify(signature, signatureLength, message, messageLength, pubKey, WK_RSA_KEYLENGTH_BYTE);
	if (retCode < 0) {
		return retCode;
	}

	return retCode;
}

int 
WKK_SIgnVerify(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength)
{
	int retCode = 0;

	retCode = WK_RSA_Verify_V15(signature, signatureLength, message, messageLength, pubKey, pubKeyLength);

	return retCode;
}

int 
WKK_SIgnVerifyHex(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, char *pubKeyHex)
{
	int retCode = 0, len;
	U8 pubKey[WK_RSA_KEYLENGTH_BYTE*2] = {0x00,};

	retCode = WK_HexToBin(pubKey, pubKeyHex);
	if (retCode < 0) {
		return retCode;
	}
	WK_Print_Hex("pubKey", pubKey, retCode, 10);

	len = retCode;
	retCode = WK_RSA_Verify_V15(signature, signatureLength, message, messageLength, pubKey, WK_RSA_KEYLENGTH_BYTE);
	if (retCode < 0) {
		return retCode;
	}

	return retCode;
}

