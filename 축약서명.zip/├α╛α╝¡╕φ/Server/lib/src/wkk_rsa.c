/* 
========================================
  wkk_rsa.c
    : The RSA public-key algorithm - RSA was designed by Ron Rivest, Adi Shamir and Len Adleman
	: FIPS PUB 198-1, The Keyed-Hash Message Authentication Code (HMAC)
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "wkk_rsa.h"
#include "wkk_asn1.h"
#include "wkk_sha256.h"
#include "wkk_error.h"
#include "wkk_util.h"
#include "wkk_bignum.h"


int 
_eSequence(U8 *src, int len)
{
	int shift = 0;
	int i = 0;

	if(len >= 256) {
		shift = 4;
	}else if(len >= 128) {
		shift = 3;
	}else {
		shift = 2;
	}

	for(i=len; i>0; i--) {
		src[i+shift-1] = src[i-1];
	}

	if(len >= 256) {
		src[0] = 0x30;
		src[1] = 0x82;
		src[2] = (U8)(len / 0x100);
		src[3] = (U8)(len % 0x100);
	}else if(len >= 128) {
		src[0] = 0x30;
		src[1] = 0x81;
		src[2] = (U8)len;
	}else {
		src[0] = 0x30;
		src[1] = (U8)len;
	}

	return shift;
}


int 
WK_PKEY_PublicKey_FromBinary(WK_RSA_PublicKey *pubKey, U8 *input, U32 inputLength)
{
	int retCode = WKK_RSA_ERROR_BAD_INPUT_DATA;
	int pos = 0;
	WK_BIGINT *big_buf;
	U8 *buf = input;

	int len, len_size;

	if(pubKey == NULL || input == NULL) {
		return WKK_RSA_ERROR_BAD_INPUT_DATA;
	}

	ASN1_TYPE_CHECK(buf, pos, WK_ASN1_TAG_SEQUENCE);
	ASN1_LENGTH_DECODE(buf, pos, len, len_size);

	// n
	big_buf = pubKey->n;
	ASN1_TYPE_CHECK(buf, pos, WK_ASN1_TAG_INTEGER);
	ASN1_LENGTH_DECODE(buf, pos, len, len_size);
	WK_Bigint_Read_Binary(big_buf, buf+pos, len);
	pos += len;

	// e
	big_buf = pubKey->e;
	ASN1_TYPE_CHECK(buf, pos, WK_ASN1_TAG_INTEGER);
	ASN1_LENGTH_DECODE(buf, pos, len, len_size);
	WK_Bigint_Read_Binary(big_buf, buf+pos, len);
	pos += len;

	retCode = 0;

end:
	return retCode;
}

void 
MGF1( U8 *dst, U32 dlen, U8 *src, U32 slen, WK_SHA256_CONTEXT *h_ctx )
{
    U8 mask[WK_SHA256_DIGEST_SIZE];
    U8 counter[4];
    U8 *p;
    U32 hlen;
    U32 i, use_len;

    memset( mask, 0, WK_SHA256_DIGEST_SIZE );
    memset( counter, 0, 4 );

    hlen = WK_SHA256_DIGEST_SIZE;

    // Generate and apply dbMask
    //
    p = dst;

    while( dlen > 0 )
    {
        use_len = hlen;
        if( dlen < hlen )
            use_len = dlen;
		
		WK_SHA256_Init(h_ctx);
		WK_SHA256_Update(h_ctx, src, slen);
		WK_SHA256_Update(h_ctx, counter, 4);
		WK_SHA256_Final(h_ctx, mask);

        for( i = 0; i < use_len; ++i )
            *p++ ^= mask[i];

        counter[3]++;

        dlen -= use_len;
    }
}


WK_RSA_PublicKey * 
WK_RSA_PublicKey_New(void)
{
	WK_RSA_PublicKey *key;

	key = (WK_RSA_PublicKey *)calloc(sizeof(WK_RSA_PublicKey), 1);
	if(key == NULL) {
		return NULL;
	}

	key->n = malloc(sizeof(WK_BIGINT));
	if(key == NULL) {
		return NULL;
	}
	WK_Bigint_New(key->n);

	key->e = malloc(sizeof(WK_BIGINT));
	if(key == NULL) {
		return NULL;
	}
	WK_Bigint_New(key->e);

	return key;
}

void 
WK_RSA_PublicKey_Free(WK_RSA_PublicKey *key)
{
	if(key != NULL) {

		WK_Bigint_Free(key->n);free(key->n);
		WK_Bigint_Free(key->e);free(key->e);

		memset(key, 0x00, sizeof(WK_RSA_PublicKey));
		free(key);

	}

	return;
}

/*
 * Check a public RSA key
 */
int 
WK_RSA_Check_Pubkey(const WK_RSA_PublicKey *key)
{
    if( !key->n->p || !key->e->p )
        return( WKK_RSA_ERROR_KEY_CHECK_FAILED );

    if( ( key->n->p[0] & 1 ) == 0 ||
		( key->e->p[0] & 1 ) == 0 ) {
			return( WKK_RSA_ERROR_KEY_CHECK_FAILED );
	}

    if( WK_Bigint_Bitlen( key->n ) < 128 ||
		WK_Bigint_Bitlen( key->n ) > WK_BIGINT_MAX_BITS ) {
			return( WKK_RSA_ERROR_KEY_CHECK_FAILED );
	}

    if( WK_Bigint_Bitlen( key->e ) < 2 ||
		WK_Bigint_Cmp_Bignum( key->e, key->n ) >= 0 ) {
			return( WKK_RSA_ERROR_KEY_CHECK_FAILED );
	}

    return( 0 );
}


/*
 * Do an RSA public key operation
 */
int 
WK_RSA_Public(WK_RSA_PublicKey *key, const U8 *input, U8 *output)
{
    int retCode;
    U32 olen;
    WK_BIGINT T;

    WK_Bigint_New( &T );

    WK_BIGINT_CHK( WK_Bigint_Read_Binary( &T, input, (key->n->n) * 4 ) );

    if( WK_Bigint_Cmp_Bignum( &T, key->n ) >= 0 ) {
        retCode = WKK_BIGNUM_ERROR_BAD_INPUT_DATA;
        goto end;
    }

    olen = (key->n->n) * 4;
    WK_BIGINT_CHK( WK_Bigint_Exp_Mod( &T, &T, key->e, key->n, NULL ) );
    WK_BIGINT_CHK( WK_Bigint_Write_Binary( &T, output, olen ) );

end:

    WK_Bigint_Free( &T );

    if( retCode != 0 )
        return( WKK_RSA_ERROR_PUBLIC_FAILED );

    return (key->n->n) * 4;
}


int 
WK_RSA_Verify(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength)
{
	int retCode = 0, i, saltLen, mHashLen;
	WK_RSA_PublicKey *key = NULL;
	U8 EM[WK_RSA_KEYLENGTH_BYTE] = {0x00,};
	U8 maskedDB[WK_RSA_KEYLENGTH_BYTE-WK_SHA256_DIGEST_SIZE-1] = {0x00,};
	U8 mgfDest[WK_RSA_KEYLENGTH_BYTE-WK_SHA256_DIGEST_SIZE-1] = {0x00,};
	U8 DB[WK_RSA_KEYLENGTH_BYTE-WK_SHA256_DIGEST_SIZE-1] = {0x00,};
	U8 salt[WK_RSA_KEYLENGTH_BYTE-WK_SHA256_DIGEST_SIZE-1] = {0x00,};
	U8 mHash[WK_RSA_KEYLENGTH_BYTE] = {0x00,};
	U8 padding1[8] = {0x00,};
	U8 H[WK_SHA256_DIGEST_SIZE] = {0x00,}, HM_[WK_SHA256_DIGEST_SIZE] = {0x00,};
	WK_SHA256_CONTEXT ctx;

	if (signature == NULL || message == NULL || pubKey == NULL)
		return WKK_RSA_ERROR_BAD_INPUT_DATA;

	if (signatureLength != WK_RSA_KEYLENGTH_BYTE)
		return WKK_RSA_ERROR_INVALID_DATALEN;

	key = WK_RSA_PublicKey_New();
	if (key == NULL)
		return WKK_RSA_ERROR_MEMORY_ALLOC_FAILED;

	retCode = WK_PKEY_PublicKey_FromBinary(key, pubKey, pubKeyLength);
	if (retCode != 0)
		goto end;

	retCode = WK_RSA_Public(key, signature, EM);
	if (retCode < 0)
		goto end;

	WK_Print_Hex("EM", EM, sizeof(EM), 10);

	// EM = maskedDB | H | bc
	if (EM[WK_RSA_KEYLENGTH_BYTE-1] != 0xbc) {
		retCode = WKK_RSA_ERROR_VERIFY_FAILED;
		goto end;
	}

	memcpy(maskedDB, EM, sizeof(maskedDB));
	WK_Print_Hex("maskedDB", maskedDB, sizeof(maskedDB), 10);

	memcpy(H, EM + sizeof(maskedDB), sizeof(H));
	WK_Print_Hex("H", H, sizeof(H), 10);

	// MGF(H)
	MGF1(mgfDest, sizeof(maskedDB), H, sizeof(H), &ctx);
	WK_Print_Hex("mgfDest", mgfDest, sizeof(mgfDest), 10);

	// DB = maskedDB ^ MGF = padding2 | salt
	for (i=0; i < sizeof(maskedDB); i++) {
		DB[i] = maskedDB[i] ^ mgfDest[i];
	}
	WK_Print_Hex("DB", DB, sizeof(DB), 10);

	for (i=0; i < sizeof(maskedDB); i++) {
		if (DB[i] == 0x01)
			break;
	}

	saltLen = sizeof(maskedDB)-i-1;
	if (saltLen <= 0) {
		retCode = WKK_RSA_ERROR_VERIFY_FAILED;
		goto end;
	}
	memcpy(salt, DB+i+1, saltLen);
	WK_Print_Hex("salt", salt, saltLen, 10);
	
	// M' = padding1 | mHash | salt
	// HM' = Hash(M')
	WK_SHA256_Digest(mHash, &mHashLen, message, messageLength); 
	WK_SHA256_Init(&ctx);
	memset(padding1, 0x00, sizeof(padding1));
	WK_SHA256_Update(&ctx, padding1, sizeof(padding1));
	WK_SHA256_Update(&ctx, mHash, mHashLen);
	WK_SHA256_Update(&ctx, salt, saltLen);
	WK_SHA256_Final(&ctx, HM_);

	// compare hash
	WK_Print_Hex("H", H, sizeof(H), 10);
	WK_Print_Hex("HM_", HM_, sizeof(H), 10);
	if (memcmp(H, HM_, sizeof(H))) {
		retCode = WKK_RSA_ERROR_VERIFY_FAILED;
		goto end;
	};
		
	retCode = 0;

end:
	WK_RSA_PublicKey_Free(key);
	return retCode;
}

int
WK_RSA_Pkcs1_EMSA_V15_Encode(U8 *output,
							 const U32 outputLength,
							 const U8 *hash,
							 const U32 hashLength)
{
	U8	sha256DER[19] = {
			0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 
			0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 
			0x00, 0x04, 0x20 };

	U8 *hashDER = NULL;
	U32	i, hashDERLength;
	int retCode;

	if ((output == NULL) || (hash == NULL))
		return WKK_RSA_ERROR_BAD_INPUT_DATA;

	//only sha256 hash algorithm 
	hashDER = sha256DER;
	hashDERLength = 19;

	if (outputLength < (hashLength + hashDERLength + 11)) {
		retCode = WKK_RSA_ERROR_INTENDED_MSG_LENGTH_TOO_SHORT;
		goto end;
	}
	
	*(output++) = 0x00;
	*(output++) = 0x01;
	for (i = 0; i <(outputLength - (hashLength + hashDERLength + 3)); i++)
			*(output++) = 0xff;
	*(output++) = 0x00;

	memcpy(output, hashDER, hashDERLength);
	memcpy(output + hashDERLength, hash, hashLength);
	
	retCode = 0;

end:

	return retCode;
}

int 
WK_RSA_Verify_V15(U8 *signature, U32 signatureLength, U8 *message, U32 messageLength, U8 *pubKey, U32 pubKeyLength)
{
	/*
	1. Check Signature S Length [S == k octets]
	2. s = IS2IP(S)
	3. m = RSAVP1 ((n, e), s)
	4. EM = I2OSP (m, k)
	5. EM' = EMSA-PKCS1-V1_5-ENCODE (M, k)
	6. compare EM == EM'

	skip 2,4
	*/

	WK_RSA_PublicKey *key = NULL;
	U8 mHash[WK_RSA_KEYLENGTH_BYTE] = {0x00,};
	U8	*buffer = NULL;
	U8	*encodeValue = NULL;
	int retCode, mHashLen;

	if ((signature == NULL) || (message == NULL) || (pubKey == NULL))
		return WKK_RSA_ERROR_BAD_INPUT_DATA;
	
	if (signatureLength != WK_RSA_KEYLENGTH_BYTE)
		return WKK_RSA_ERROR_INVALID_DATALEN;

	buffer = (U8 *) malloc(WK_RSA_KEYLENGTH_BYTE);
	if (buffer == NULL) {
		retCode = WKK_RSA_ERROR_MEMORY_ALLOC_FAILED;
		goto end;
	}

	encodeValue = (U8 *)malloc(WK_RSA_KEYLENGTH_BYTE);
	if (encodeValue == NULL) {
		retCode = WKK_RSA_ERROR_MEMORY_ALLOC_FAILED;
		goto end;
	}

	memset (buffer, 0x00, WK_RSA_KEYLENGTH_BYTE);
	memset (encodeValue, 0x00, WK_RSA_KEYLENGTH_BYTE);

	key = WK_RSA_PublicKey_New();
	if (key == NULL)
		return WKK_RSA_ERROR_MEMORY_ALLOC_FAILED;

	retCode = WK_PKEY_PublicKey_FromBinary(key, pubKey, pubKeyLength);
	if (retCode != 0)
		goto end;

	retCode = WK_RSA_Public(key, signature, buffer);
	if (retCode < 0) {
		goto end;
	}

	WK_SHA256_Digest(mHash, &mHashLen, message, messageLength); 
	retCode = WK_RSA_Pkcs1_EMSA_V15_Encode(encodeValue, WK_RSA_KEYLENGTH_BYTE, mHash, mHashLen);
	if (retCode) {
		if (retCode == WKK_RSA_ERROR_INTENDED_MSG_LENGTH_TOO_SHORT)
			retCode = WKK_RSA_ERROR_MODULUS_TOO_SHORT;
		goto end;
	}

	WK_Print_Hex("encodeValue", encodeValue, WK_RSA_KEYLENGTH_BYTE, 10);
	WK_Print_Hex("buffer", buffer, WK_RSA_KEYLENGTH_BYTE, 10);
	if (memcmp(encodeValue, buffer, WK_RSA_KEYLENGTH_BYTE)) {
		retCode = WKK_RSA_ERROR_VERIFY_FAILED;
		goto end;
	}

	retCode = 0;

end:
	free(buffer);
	free(encodeValue);

	return retCode;

}
