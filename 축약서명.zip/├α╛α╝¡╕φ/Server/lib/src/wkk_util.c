/* 
========================================
  wkk_util.c
----------------------------------------
  Whykeykey(c).
  2016.12.
========================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wkk_util.h"
#include "wkk_error.h"

int 
WK_Uint32ToByte (U8 *buf, U32 a)
{
	int pos = 0;

	buf[pos++] = (U8)((a >> 24) & 0x000000FF);
	buf[pos++] = (U8)((a >> 16) & 0x000000FF);
	buf[pos++] = (U8)((a >> 8) & 0x000000FF);
	buf[pos++] = (U8)(a & 0x000000FF);

	return pos;
}

/* For Network Byte Order : Big Endian */
U32 
WK_ByteToUint32 (U8 *buf)
{
	U32 a = 0;
	int pos = 0;

	a = (U32)buf[pos++] << 24;
	a|= (U32)buf[pos++] << 16;
	a|= (U32)buf[pos++] << 8;
	a|= (U32)buf[pos++];

	return a;
}

void 
WK_Print_Hex (char *title, unsigned char *data, int len, int mod)
{
#ifdef _DEBUG
	unsigned char buf[256+1], *p;
	int   nleft, i, j, buf_len;

	printf("[%s] %d bytes\n", title, len);

	nleft = len;
	p = data;

	for (i=0; i < len;) {
		printf("    %04x - ", i);

		/* Fill buf */
		if (nleft >= mod)
			buf_len = mod;
		else
			buf_len = nleft;

		memcpy(buf, p, buf_len);

		/* Print buf content as hex */
		for (j=0; j < buf_len; j++) {
			printf("%02x:", buf[j]);
		}
		if (buf_len < mod) {
			for(j=0; j < (mod - buf_len); j++)
				printf("   ");
		}

		/* Print buf content as char */
		for (j=0; j < buf_len; j++) {
			if ((buf[j] < ' ') || ('~' < buf[j])) {
				buf[j] = '.';
			}
		}
		buf[buf_len] = '\0';
		printf("   %s\n", buf);

		/* Update variables */
		nleft -= buf_len;
		i += buf_len;
		p += buf_len;
	}
#endif
	return;
}

static int
_GetBin(int x)
{
	if (x >= '0' && x <= '9')
		return x - '0';

	if (x >= 'A' && x <= 'F')
		return x - 'A' + 10;

	if (x >= 'a' && x <= 'f')
		return x - 'a' + 10;

	return WKK_COMMON_ERROR_INVALID_INPUT;
}

int 
WK_HexToBin(unsigned char *out, char *hexString)
{
	int len, i;
	char *p = hexString;

	len = (int)strlen(hexString);
	if (len <=0 || (len % 2) != 0)
		return WKK_COMMON_ERROR_INVALID_INPUT;

	for (i=0; i<len; i+=1) {
		if (_GetBin(p[i]) < 0)
			WKK_COMMON_ERROR_INVALID_INPUT;
	}
	for (i=0; i<len; i+=2) {
		out[i/2] = _GetBin(p[i]) << 4;
		out[i/2] |= _GetBin(p[i+1]);
	}

	return len/2;
}
