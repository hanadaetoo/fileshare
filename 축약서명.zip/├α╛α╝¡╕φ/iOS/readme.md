# Whykeykey_BriefSign-iOS

## WKKPkcs1
\+ (NSData \*) pkcs1SignWithPureKey : (NSData \*) src privateKey : (NSData \*) privateKey error : (NSError \*\*) error

 (NSData \*) src - 서명 원문
 (NSData \*) privateKey - pure key
 (NSError \*) error - NSError 객체

    NSString * privateKeyHex = @"PRIVATEKEY_HEX";

    NSData * privateKeyData = [WKKUtil hexDecode:privateKeyHex];

    NSError * error;

        NSData * signedData = [WKKPkcs1 pkcs1SignWithPureKey:[@"This is plain msg" dataUsingEncoding:NSUTF8StringEncoding] privateKey:privateKeyData error:&error];
        if (error) {
            NSLog(@"error : %ld, %@", [error code], [error localizedDescription]);
        } else {
            NSLog(@"%@ \n length : %ld", signedData, [signedData length]);
        }

FIDO 연계앱으로 부터 받은 key-pair를 이용하여 pkcs1 서명을 진행한다.

\+ (NSData \*) pkcs1SignWithPkcs8Key : (NSData \*) src privateKey : (NSData \*) privateKey error : (NSError \*\*) error

(NSData \*) src - 서명 원문
(NSData \*) privateKey - PKCS#8 encoded privatekey
(NSError \*) error - NSError 객체

	NSString * privateKeyHex = @"PRIVATEKEY_HEX";

    NSData * privateKeyData = [WKKUtil hexDecode:privateKeyHex];

    NSError * error;

        NSData * signedData = [WKKPkcs1 pkcs1SignWithPkcs8Key:[@"This is plain msg" dataUsingEncoding:NSUTF8StringEncoding] privateKey:privateKeyData error:&error];
        if (error) {
            NSLog(@"error : %ld, %@", [error code], [error localizedDescription]);
        } else {
            NSLog(@"%@ \n length : %ld", signedData, [signedData length]);
        }

pkcs#8 인코딩된 privatekey를 이용하여 pkcs1 서명을 진행한다.

## WKKUtil
\+ (NSData \*) hexDecode : (NSString \*) str ;

(NSString \*) str - hex string

	NSData * decoded = [WKKUtil hexDecode: hex];

hex string 을 hex decode 하여 NSData \* 형태로 반환한다.

\+ (NSString \*) hexEncode : (NSData \*) data;

(NSData \*) data - binary

	NSString * encoded = [WKKUtil hexEncode: data];

NSData \* 형태의 binary를 hex encode 하여 NSString \* 형태로 반환한다.


## ErrorCode

* code : 1 \- localizedDescription : Keychain에 privateKey를 넣을 수 없습니다.
* code : 2 \- localizedDescription : 서명에 실패하였습니다.
* code : 3 \- localizedDescription : 입력받은 privatekey 변환에 실패하였습니다. 올바른 PKCS8 privatekey인지 확인해 주십시오.
* code : 4 \- localizedDescription : %s 데이터가 올바르지 않습니다.
