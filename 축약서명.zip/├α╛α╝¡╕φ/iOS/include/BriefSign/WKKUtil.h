//
//  LNKUtil.h
//  lnkapp
//
//  Created by leafN on 2016. 8. 26..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WKKUtil : NSObject

+ (NSData *) hexDecode : (NSString *) str ;
+ (NSString *) hexEncode : (NSData *) data;

@end
