//
//  BriefSign.h
//  BriefSign
//
//  Created by leafN on 2016. 12. 6..
//  Copyright © 2016년 Whykeykey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WKKPkcs1 : NSObject

+ (NSData *) pkcs1SignWithPureKey : (NSData *) src privateKey : (NSData *) privateKey error : (NSError **) error;
+ (NSData *) pkcs1SignWithPkcs8Key : (NSData *) src privateKey : (NSData *) privateKey error : (NSError **) error;


@end
