//
//  LNKDebug.h
//  lnkapp
//
//  Created by leafN on 2016. 8. 26..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LNKDebug : NSObject

// Xcode 8.0 의 버그로 인하여 만듬
+ (void) LNKLog : (NSString *) format, ... /*NS_REQUIRES_NIL_TERMINATION*/;

@end
