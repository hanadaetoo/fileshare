//
//  LNKComLnkapp.h
//  lnkFramework
//
//  Created by leafN on 2016. 8. 31..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LNKComLnkapp : NSObject

+ (BOOL) communicateLnkAppWithScheme : (NSDictionary *) param scheme : (NSString *) scheme error : (NSError **) error;

+ (NSDictionary *) parseUrlComponents : (NSURL *) url;

+ (BOOL) isTouchIDEnrolled;

+ (BOOL) isLnkAppInstalled;

@end
