//
//  LNKComLnkapp.m
//  lnkFramework
//
//  Created by leafN on 2016. 8. 31..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import "LNKComLnkapp.h"
#import "LNKConst.h"
#import "LocalAuthentication/LocalAuthentication.h"

@implementation LNKComLnkapp



#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

// 사용자의 디바이스에서 LAContext(TouchID API)가 사용가능한지 여부를 확인하는 메서드
+ (BOOL) isTouchIDEnrolled
{
    if(!SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"9.0")) return FALSE;
    if (NSClassFromString(@"LAContext")) {
        return [[[LAContext alloc] init] canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:nil];
    }
    return FALSE;
}

// 연계앱이 설치되어 있는지 확인하는 메서드
// 사용하려면 반드시 금융앱의 info.plist > URL Types 부분에 lnkApp이 정의되어 있어야함.
+ (BOOL) isLnkAppInstalled
{
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"lnkApp://"]];
}

// 연계앱과의 URL Scheme을 진행하는 메서드
// 오류 발생시 NSError를 통하여 에러를 리턴하고, 메서드에서는 false를 반환함
+ (BOOL) communicateLnkAppWithScheme : (NSDictionary *) param scheme : (NSString *) scheme error : (NSError **) error{
    
    NSMutableDictionary * details = [NSMutableDictionary dictionary];
    
    // 데이터 확인
    BOOL ret = [self dataChecker:error param:param];
    if (!ret) {
        return FALSE;
    }
    
    // URL Scheme URI생성
    NSURL * url = [self makeURLScheme:param scheme:scheme];
    
    // URL Scheme 진행
    if(![[UIApplication sharedApplication] openURL:url]) {
        [details setValue:@"URL Scheme을 진행할 수 없습니다." forKey:NSLocalizedDescriptionKey];
        *error = [NSError errorWithDomain:@"URL" code:100 userInfo:details];
        return FALSE;
    }
    return TRUE;
}

// URI 생성
+ (NSURL *) makeURLScheme : (NSDictionary *) param scheme : (NSString *) scheme {
    NSMutableString * url = [[NSMutableString alloc] initWithString:LNK_APP_SCHEME];
    
    NSData * parameterData = [NSJSONSerialization dataWithJSONObject:param options:NSJSONWritingPrettyPrinted error:nil];
    NSString * encodedString = [parameterData base64EncodedStringWithOptions:0];
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    encodedString = [encodedString stringByReplacingOccurrencesOfString:@"=" withString:@""];
    
    [url appendString:[NSString stringWithFormat:@"://x-callback-url/?x-success=%@%@&param=%@", scheme, @"://x-callback-url/", encodedString]];
    
    return [[NSURL alloc] initWithString:url];
}

// 연계앱으로 전송할 데이터가 올바른지 확인
+ (BOOL) dataChecker : (NSError **) error param : (NSDictionary *) param {
    
    NSMutableDictionary * details = [NSMutableDictionary dictionary];
    
    if(param == nil) {
        [details setValue:@"JSON 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
        *error = [NSError errorWithDomain:@"JSON" code:200 userInfo:details];
    
        return FALSE;
    }
    
    
    
    if([param objectForKey:DATA_KEY_CODE] == nil ||
       [[param objectForKey:DATA_KEY_CODE] isEqual:[NSNull null]]) {
        [details setValue:@"DATA_KEY_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
        *error = [NSError errorWithDomain:@"JSON" code:201 userInfo:details];
        
        return FALSE;
    }
    
    NSInteger keyCode = [[param objectForKey:DATA_KEY_CODE] integerValue];
    
    switch (keyCode) {
        case 101:
            break;
        case 103:
            if([param objectForKey:DATA_KEY_FIDO] == nil ||
               [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:202 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_TLS_CERT] == nil ||
                      [[param objectForKey:DATA_KEY_TLS_CERT] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_TLS_CERT 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:203 userInfo:details];
                
                return FALSE;
            }
            break;
        case 105:
            
            if([param objectForKey:DATA_KEY_ENC_NIDCN] == nil ||
               [[param objectForKey:DATA_KEY_ENC_NIDCN] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_ENC_NIDCN 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:204 userInfo:details];
                
                return FALSE;
            } else if ([param objectForKey:DATA_KEY_COMPATIBLE] == nil ||
                       [[param objectForKey:DATA_KEY_COMPATIBLE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_COMPATIBLE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:205 userInfo:details];
                
                return FALSE;
            }
            break;
        case 111:
            break;
        case 113:
            break;
        case 115:
            if([param objectForKey:DATA_KEY_SITE_CODE] == nil ||
               [[param objectForKey:DATA_KEY_SITE_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SITE_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:206 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_SVC_CODE] == nil ||
                      [[param objectForKey:DATA_KEY_SVC_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SVC_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:207 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_NIDCT_CHALLENGE] == nil ||
                      [[param objectForKey:DATA_KEY_NIDCT_CHALLENGE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCT_CHALLENGE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:208 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_FIDO] == nil ||
                      [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:209 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_TLS_CERT] == nil ||
                      [[param objectForKey:DATA_KEY_TLS_CERT] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_TLS_CERT 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:210 userInfo:details];
                
                return FALSE;
            }
            break;
        case 121:
            if([param objectForKey:DATA_KEY_SITE_CODE] == nil ||
               [[param objectForKey:DATA_KEY_SITE_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SITE_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:211 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_SVC_CODE] == nil ||
                      [[param objectForKey:DATA_KEY_SVC_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SVC_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:212 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_TLS_CERT] == nil ||
                      [[param objectForKey:DATA_KEY_TLS_CERT] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_TLS_CERT 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:213 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_FIDO] == nil ||
                      [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:214 userInfo:details];
                
                return FALSE;
            }
            break;
        case 201:
            break;
        case 203:
            break;
        case 205:
            if([param objectForKey:DATA_KEY_ENC_NIDCN] == nil ||
               [[param objectForKey:DATA_KEY_ENC_NIDCN] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_ENC_NIDCN 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:215 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_COMPATIBLE] == nil ||
                      [[param objectForKey:DATA_KEY_COMPATIBLE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_COMPATIBLE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:216 userInfo:details];
                
                return FALSE;
            }
            break;
        case 211:
            break;
        case 213:
            break;
        case 215:
            if([param objectForKey:DATA_KEY_ENC_NIDCN] == nil ||
               [[param objectForKey:DATA_KEY_ENC_NIDCN] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_ENC_NIDCN 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:217 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_COMPATIBLE] == nil ||
                      [[param objectForKey:DATA_KEY_COMPATIBLE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_COMPATIBLE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:218 userInfo:details];
                
                return FALSE;
            }
            break;
        case 221:
            if([param objectForKey:DATA_KEY_SITE_CODE] == nil ||
               [[param objectForKey:DATA_KEY_SITE_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SITE_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:219 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_SVC_CODE] == nil ||
                      [[param objectForKey:DATA_KEY_SVC_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SVC_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:220 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_NIDCT_CHALLENGE] == nil ||
                      [[param objectForKey:DATA_KEY_NIDCT_CHALLENGE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCT_CHALLENGE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:221 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_AAID] == nil ||
                      [[param objectForKey:DATA_KEY_AAID] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_AAID 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:222 userInfo:details];
                
                return FALSE;
            }
            break;
        case 223:
            break;
        case 231:
            if([param objectForKey:DATA_KEY_SITE_CODE] == nil ||
                [[param objectForKey:DATA_KEY_SITE_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SITE_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:223 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_SVC_CODE] == nil ||
                [[param objectForKey:DATA_KEY_SVC_CODE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_SVC_CODE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:224 userInfo:details];
                
                return FALSE;
            }
            break;
        case 301:
            break;
        case 311:
            if([param objectForKey:DATA_KEY_NIDCN_AAID] == nil ||
                [[param objectForKey:DATA_KEY_NIDCN_AAID] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCN_AAID 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:225 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_NIDCT_CHALLENGE] == nil ||
                [[param objectForKey:DATA_KEY_NIDCT_CHALLENGE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCT_CHALLENGE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:226 userInfo:details];
                
                return FALSE;
            } else if([param objectForKey:DATA_KEY_TLS_CERT] == nil ||
                [[param objectForKey:DATA_KEY_TLS_CERT] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_TLS_CERT 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:227 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_FIDO] == nil ||
                [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:228 userInfo:details];
                    
                return FALSE;
            }
            break;
        case 321:
            if([param objectForKey:DATA_KEY_PKG_ID] == nil ||
                [[param objectForKey:DATA_KEY_PKG_ID] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_PKG_ID 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:229 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_NIDCN_AAID] == nil ||
                [[param objectForKey:DATA_KEY_NIDCN_AAID] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCN_AAID 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:230 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_NIDCT_CHALLENGE] == nil ||
                [[param objectForKey:DATA_KEY_NIDCT_CHALLENGE] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_NIDCT_CHALLENGE 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:231 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_FIDO] == nil ||
                [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:232 userInfo:details];
                    
                return FALSE;
            }
            break;
        case 323:
            if ([param objectForKey:DATA_KEY_FIDO] == nil ||
                [[param objectForKey:DATA_KEY_FIDO] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:236 userInfo:details];
                    
                return FALSE;
            } else if([param objectForKey:DATA_KEY_FIDO_AUTH_RESULT] == nil ||
                [[param objectForKey:DATA_KEY_FIDO_AUTH_RESULT] isEqual:[NSNull null]]) {
                [details setValue:@"DATA_KEY_FIDO_AUTH_RESULT 데이터가 없습니다." forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"JSON" code:237 userInfo:details];
            }
            break;
        case 401:
            break;
        default:
            [details setValue:@"DATA_KEY_CODE 데이터가 잘못되었습니다." forKey:NSLocalizedDescriptionKey];
            *error = [NSError errorWithDomain:@"JSON" code:299 userInfo:details];
                
            return FALSE;
            break;
    }
    
    return TRUE;
}


#pragma mark - parseUrlComponents
+ (NSDictionary *) parseUrlComponentsGreaterThan8 : (NSArray *) queryItems {
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    for(NSURLQueryItem *item in queryItems){
        [dict setValue:item.value forKey: item.name];
    }
    
    return dict;
}

+ (NSDictionary *) parseUrlComponents : (NSURL *) url {
    NSURLComponents * urlComponents = [NSURLComponents componentsWithURL: url resolvingAgainstBaseURL: NO];
    
    NSMutableDictionary * params;
    
    if (SYSTEM_VERSION_GREATER_THAN(@"8.2")) {
        params = [[self parseUrlComponentsGreaterThan8: urlComponents.queryItems] mutableCopy];
    }
    else {
        NSString * urlParametersBuffer = urlComponents.query;
        params = [[NSMutableDictionary alloc] init];
        for (NSString *param in [urlParametersBuffer componentsSeparatedByString:@"&"]) {
            NSArray *elts = [param componentsSeparatedByString:@"="];
            if([elts count] < 2) continue;
            [params setObject:[elts lastObject] forKey:[elts firstObject]];
        }
    }
    
    return params;
}

@end

