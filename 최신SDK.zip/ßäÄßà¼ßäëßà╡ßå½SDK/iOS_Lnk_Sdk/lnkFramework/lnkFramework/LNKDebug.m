//
//  LNKDebug.m
//  lnkapp
//
//  Created by leafN on 2016. 8. 26..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import "LNKDebug.h"

@implementation LNKDebug

+ (void) LNKLog : (NSString *) format, ...{
    va_list args;
    va_start(args, format);
    
    NSString * output = [[NSString alloc] initWithFormat:format arguments:args];
    if([output length] > 1023) {
        for(int i = 0; i < ([output length] / 1023) + 1; i++) {
            
            if(i == ([output length] / 1023)) {
                NSLog(@"%@", [output substringWithRange:NSMakeRange((i * 1023), [output length] - (i * 1023))]);
            } else {
                NSLog(@"%@", [output substringWithRange:NSMakeRange((i * 1023), 1023)]);
            }
            
        }
    } else {
        NSLog(@"%@", output);
    }
    
    va_end(args);
}

@end
