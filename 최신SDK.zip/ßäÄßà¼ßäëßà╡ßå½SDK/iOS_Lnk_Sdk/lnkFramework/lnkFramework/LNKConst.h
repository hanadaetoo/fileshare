//
//  LNKConst.h
//  lnkapp
//
//  Created by leafN on 2016. 8. 26..
//  Copyright © 2016년 kftc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)

// 연계앱의 URL Scheme
#define LNK_APP_SCHEME @"lnkApp"

// 공동 FIDO 등록
#define CODE_101 @"101"
#define CODE_102 @"102"
#define CODE_103 @"103"
#define CODE_104 @"104"
#define CODE_105 @"105"
#define CODE_106 @"106"

// 공동 FIDO 인증
#define CODE_111 @"111"
#define CODE_112 @"112"
#define CODE_113 @"113"
#define CODE_114 @"114"
#define CODE_115 @"115"
#define CODE_116 @"116"

// 공동 FIDO 해지
#define CODE_121 @"121"
#define CODE_122 @"122"

// 개별 FIDO 등록
#define CODE_201 @"201"
#define CODE_202 @"202"
#define CODE_203 @"203"
#define CODE_204 @"204"
#define CODE_205 @"205"
#define CODE_206 @"206"

// 개별 FIDO 기사용자 등록
#define CODE_211 @"211"
#define CODE_212 @"212"
#define CODE_213 @"213"
#define CODE_214 @"214"
#define CODE_215 @"215"
#define CODE_216 @"216"

// 개별 FIDO 인증
#define CODE_221 @"221"
#define CODE_222 @"222"
#define CODE_223 @"223"
#define CODE_224 @"224"

// 개별 FIDO 해지
#define CODE_231 @"231"
#define CODE_232 @"232"

// 비식별호환번호목록 조회
#define CODE_301 @"301"
#define CODE_302 @"302"

// 공동 FIDO 호환인증
#define CODE_311 @"311"
#define CODE_312 @"312"

// 개별 FIDO 호환인증
#define CODE_321 @"321"
#define CODE_322 @"322"
#define CODE_323 @"323"
#define CODE_324 @"324"

// get AppVersion & UUID ( for iOS )
#define CODE_401 @"401"
#define CODE_402 @"402"


// Data Access Key

#define DATA_KEY_CODE               @"DATA_KEY_CODE"
#define DATA_KEY_VERSION            @"DATA_KEY_VERSION"
#define DATA_KEY_FIDO               @"DATA_KEY_FIDO"
#define DATA_KEY_DEVICE_ID          @"DATA_KEY_DEVICE_ID"
#define DATA_KEY_ENC_NIDCN          @"DATA_KEY_ENC_NIDCN"
#define DATA_KEY_PUBKEY             @"DATA_KEY_PUBKEY"
#define DATA_KEY_PRIVKEY            @"DATA_KEY_PRIVKEY"
#define DATA_KEY_SVC_CODE           @"DATA_KEY_SVC_CODE"
#define DATA_KEY_AUTH_CODE          @"DATA_KEY_AUTH_CODE"
#define DATA_KEY_TRX_TYPE           @"DATA_KEY_TRX_TYPE"
#define DATA_KEY_OTP                @"DATA_KEY_OTP"
#define DATA_KEY_AAID               @"DATA_KEY_AAID"
#define DATA_KEY_SITE_CODE          @"DATA_KEY_SITE_CODE"
#define DATA_KEY_SVC_CODE           @"DATA_KEY_SVC_CODE"
#define DATA_KEY_DEREG_RESULT       @"DATA_KEY_DEREG_RESULT"
#define DATA_KEY_NIDCN_LIST         @"DATA_KEY_NIDCN_LIST"
#define DATA_KEY_PKG_ID             @"DATA_KEY_PKG_ID"
#define DATA_KEY_SVC_ID             @"DATA_KEY_SVC_ID"
#define DATA_KEY_DEL_NIDCN_RESULT   @"DATA_KEY_DEL_NIDCN_RESULT"
#define DATA_KEY_TLS_CERT           @"DATA_KEY_TLS_CERT"
#define DATA_KEY_SAVE_NIDCN_RESULT  @"DATA_KEY_SAVE_NIDCN_RESULT"
#define DATA_KEY_NIDCT_CHALLENGE    @"DATA_KEY_NIDCT_CHALLENGE"
#define DATA_KEY_NIDCT              @"DATA_KEY_NIDCT"
#define DATA_KEY_NIDCN_AAID         @"DATA_KEY_NIDCN_AAID"
#define DATA_KEY_CB                 @"DATA_KEY_CB"
#define DATA_KEY_COMPATIBLE         @"DATA_KEY_COMPATIBLE"
#define DATA_KEY_ERROR_CODE         @"DATA_KEY_ERROR_CODE"
#define DATA_KEY_DEVICE_ID          @"DATA_KEY_DEVICE_ID"
#define DATA_KEY_FIDO_AUTH_RESULT   @"DATA_KEY_FIDO_AUTH_RESULT"

// errorCode

#define DATA_KEY_CODE_ERROR         @"1000"

#define ERROR_DATA_INVALID_CODE                             @"-1101"
#define ERROR_DATA_INVALID_FIDO_MESSAGE                     @"-1102"
#define ERROR_DATA_INVALID_CHANNEL_BINDING                  @"-1103"
#define ERROR_DATA_INVALID_SITE_CODE                        @"-1104"
#define ERROR_DATA_INVALID_SVC_CODE                         @"-1105"
#define ERROR_DATA_INVALID_NIDCT_CHALLENGE                  @"-1106"
#define ERROR_DATA_INVALID_AAID                             @"-1107"
#define ERROR_DATA_INVALID_TLS_CERT                         @"-1108"
#define ERROR_DATA_INVALID_NIDCN_AAID                       @"-1109"
#define ERROR_DATA_INVALID_ENC_NIDCN                        @"-1110"
#define ERROR_DATA_INVALID_COMPATIBLE_TYPE                  @"-1111"
#define ERROR_DATA_INVALID_PKG_ID                           @"-1112"

#define ERROR_FIDO_USER_CANCELLED                           @"-1203"
#define ERROR_FIDO_UNSUPPORTED_VERSION                      @"-1204"
#define ERROR_FIDO_NO_SUITABLE_AUTHENTICATOR                @"-1205"
#define ERROR_FIDO_UNTRUSTED_FACET_ID                       @"-1207"
#define ERROR_FIDO_INVALID_MESSAGE                          @"-1250"
#define ERROR_FIDO_PARSE_AAID                               @"-1252"
#define ERROR_FIDO_FINGERPRINT_NOT_ENROLLED                 @"-1260"
#define ERROR_FIDO_UNKNOWN                                  @"-1290"

#define ERROR_CRYPTO_GENERATE_KEYPAIR                       @"-1301"
#define ERROR_CRYPTO_GENERATE_NIDCT                         @"-1302"
#define ERROR_DATABASE                                      @"-1400"
#define ERROR_DATABASE_DELETE                               @"-1401"
#define ERROR_DATABASE_READ                                 @"-1402"

#define ERROR_COMPATIBLE_CANCELED                           @"-1601"
#define ERROR_COMPATIBLE_FAIL                               @"-1602"
#define ERROR_COMPATIBLE_DISALLOWED_APP                     @"-1603"
#define ERROR_COMPATIBLE_INVALID_FIDO_MESSAGE               @"-1604"
#define ERROR_COMPATIBLE_INVALID_AUTH_RESULT                @"-1605"
