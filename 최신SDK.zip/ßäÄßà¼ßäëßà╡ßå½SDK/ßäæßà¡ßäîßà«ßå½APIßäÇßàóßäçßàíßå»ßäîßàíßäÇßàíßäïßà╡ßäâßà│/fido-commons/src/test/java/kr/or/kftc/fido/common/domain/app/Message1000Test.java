package kr.or.kftc.fido.common.domain.app;

import android.os.Bundle;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.PrintWriter;
import java.io.StringWriter;

import kr.or.kftc.fido.common.CommonConstant;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by shchoi on 2017-04-02.
 */
@RunWith(MockitoJUnitRunner.class)
public class Message1000Test {

    private Message1000 message1000;

    @Before
    public void setUp() {
        Bundle bundle = Mockito.mock(Bundle.class);
        bundle.putString(CommonConstant.KEY_ERROR_CODE, "1002");

        try {
            message1000 = new Message1000(bundle);
        } catch(InvalidParameterException e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.out.println(writer.toString());

            message1000 = null;
        }
    }

    @Test
    public void testMessage1000ErrorHappyCase() {
        final int errorCode = message1000.getErrorCode();
        assertThat(errorCode).isEqualTo(1002);
    }
}