package kr.or.kftc.fido.common.domain.fido;

import java.io.Serializable;
import java.lang.reflect.Field;

import kr.or.kftc.fido.common.di.StringField;
import kr.or.kftc.fido.common.exception.domain.InvalidLengthException;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;
import kr.or.kftc.fido.common.util.StringUtil;

/**
 * Created by shchoi on 2017-04-05.
 */

public class NidcnPrefix implements Serializable {
    public static final int AUTH_TECH_FINGER_PRINT = 100;
    public static final int AUTH_TECH_IRIS = 104;

    @StringField(type = "N", length = 5) String organCode;
    @StringField(type = "N", length = 3) String serviceCode;
    @StringField(type = "N", length = 3) String authTechCode;
    @StringField(type = "N", length = 2) String regWayCode;

    public NidcnPrefix(String nidcnPrefix) throws InvalidParameterException {
        if(nidcnPrefix == null || nidcnPrefix.length() != 13)
            throw new InvalidLengthException(InvalidLengthException.TYPE_LENGTH, "nidcnPrefix");
        this.organCode = nidcnPrefix.substring(0, 5);
        this.serviceCode = nidcnPrefix.substring(5, 8);
        this.authTechCode = nidcnPrefix.substring(8, 11);
        this.regWayCode = nidcnPrefix.substring(11, 13);

        try {
            checkFields();
        } catch(IllegalAccessException e) {
            throw new InvalidParameterException(e.getClass().getName() + " "
                    + this.getClass().getName());
        }
    }

    public String getAuthTech() {
        int code = Integer.valueOf(authTechCode);
        switch(code) {
            case AUTH_TECH_FINGER_PRINT :
                return "지문";
            case AUTH_TECH_IRIS :
                return "홍채";
            default:
                return "???";
        }
    }

    public String getOrganCode() {
        return this.organCode;
    }

    public String getServiceCode() {
        return this.serviceCode;
    }

    protected void checkFields() throws InvalidParameterException, IllegalAccessException {
        for(Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            StringUtil.checkStringField(field, String.valueOf(field.get(this)));
        }
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof NidcnPrefix))
            return false;
        NidcnPrefix nidcnPrefix = (NidcnPrefix)obj;
        if(nidcnPrefix.getOrganCode().equals(getOrganCode())
                && nidcnPrefix.getAuthTech().equals(getAuthTech())
                && nidcnPrefix.getServiceCode().equals(getServiceCode()))
            return true;
        return false;
    }

    @Override
    public String toString() {
        return organCode+serviceCode+authTechCode+regWayCode;
    }
}
