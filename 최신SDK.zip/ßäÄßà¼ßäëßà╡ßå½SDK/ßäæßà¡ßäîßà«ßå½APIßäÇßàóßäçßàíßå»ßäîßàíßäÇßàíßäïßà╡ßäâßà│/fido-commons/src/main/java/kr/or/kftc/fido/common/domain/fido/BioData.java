package kr.or.kftc.fido.common.domain.fido;

import java.lang.reflect.Field;
import java.util.StringTokenizer;

import kr.or.kftc.fido.common.di.StringField;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;
import kr.or.kftc.fido.common.util.StringUtil;

/**
 * Created by shchoi on 2017-04-03.
 */

public class BioData {
    @StringField(type = "N", length = 13) private String nidcn_prefix;
    @StringField(type = "ANS", length = 9) private String aaid;
    @StringField(type = "A", length = 1) private String fidoType;

    public BioData(String bioData) throws InvalidParameterException {
        if(bioData == null || bioData.length() != 25)
            throw new InvalidParameterException("BioData");

        StringTokenizer tokenizer = new StringTokenizer(bioData, "|");
        this.nidcn_prefix = tokenizer.nextToken();
        this.aaid = tokenizer.nextToken();
        this.fidoType = tokenizer.nextToken();

        try {
            checkFields();
        } catch(IllegalAccessException e) {
            throw new InvalidParameterException(e.getClass().getName() + " "
                    + this.getClass().getName());
        }
    }

    public String getNidcnPrefix() {
        return nidcn_prefix;
    }

    public String getAaid() {
        return aaid;
    }

    public boolean isPublicBioData() {
        if("P".equals(fidoType))
            return true;
        return false;
    }

    protected void checkFields() throws InvalidParameterException, IllegalAccessException {
        for(Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            StringUtil.checkStringField(field, String.valueOf(field.get(this)));
        }
    }
}
