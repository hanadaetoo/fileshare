package kr.or.kftc.fido.common.exception.system;

/**
 * 기기정보를 획득하는 과정에서 발생하는 오류
 */
public class DeviceException extends Exception {
    public DeviceException(String exceptionType) {
        super(exceptionType);
    }
}
