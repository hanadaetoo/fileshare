package kr.or.kftc.fido.common.domain.app;

import android.os.Bundle;

/**
 * Created by shchoi on 2017-03-28.
 */

public interface ApplicationRequest {

    Bundle asBundle();
}
