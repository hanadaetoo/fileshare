package kr.or.kftc.fido.common.communicate.app;

import android.content.Context;
import android.content.Intent;

import kr.or.kftc.fido.common.domain.app.ApplicationRequest;
import kr.or.kftc.fido.common.exception.system.MessageServiceException;

/**
 * Created by shchoi on 2017-03-28.
 */
public class MessageCommunicator {
    private Context context;
    private String targetPackage;

    /**
     * Constructor of MessageCommunicator
     * @param context Application context
     * @param targetPackage target package : LnkApp
     */
    public MessageCommunicator(Context context, String targetPackage) {
        this.context = context;
        this.targetPackage = targetPackage;
    }

    public void registerCallback(MessageCallback callback) throws MessageServiceException {
        MessageService.registerCallback(callback);
    }

    public void unregisterCallback() {
        MessageService.unregisterCallback();
    }

    public void sendMessage(ApplicationRequest applicationRequest) throws MessageServiceException {
        if(applicationRequest == null)
            throw new MessageServiceException("applicationRequest");

        Intent intent = new Intent(context, MessageService.class);
        intent.putExtra(MessageService.EXTRA_TARGET_PACKAGE, targetPackage);
        intent.putExtras(applicationRequest.asBundle());
        context.startService(intent);
    }
}