package kr.or.kftc.fido.common.communicate.app;

import android.os.Message;

/**
 * Created by shchoi on 2017-04-14.
 */

public interface MessageHandlePolicy {

    boolean onReceiveMessage(Message message);

}
