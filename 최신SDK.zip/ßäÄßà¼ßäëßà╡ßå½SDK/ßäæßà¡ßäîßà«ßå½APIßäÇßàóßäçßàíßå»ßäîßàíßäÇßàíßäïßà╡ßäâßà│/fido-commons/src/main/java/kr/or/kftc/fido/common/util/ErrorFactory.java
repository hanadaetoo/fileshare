package kr.or.kftc.fido.common.util;

import java.net.SocketTimeoutException;

import kr.or.kftc.fido.common.exception.LnkAppException;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;
import kr.or.kftc.fido.common.exception.net.NetworkException;
import kr.or.kftc.fido.common.exception.net.ServerException;
import kr.or.kftc.fido.common.exception.system.DeviceException;
import kr.or.kftc.fido.common.exception.system.EncryptionException;
import kr.or.kftc.fido.common.exception.system.MessageServiceException;

/**
 * Created by shchoi on 2017-03-28.
 */
public class ErrorFactory {
    public static final int ERROR_DATA_INVALID = -1100;
    public static final int ERROR_DATA_INVALID_CODE = -1101;
    public static final int ERROR_DATA_INVALID_FIDO_MESSAGE = -1102;
    public static final int ERROR_DATA_INVALID_CHANNEL_BINDING = -1103;
    public static final int ERROR_DATA_INVALID_SITE_CODE = -1104;
    public static final int ERROR_DATA_INVALID_SVC_DOE = -1105;
    public static final int ERROR_DATA_INVALID_NIDCT_CHALLENGE = -1106;
    public static final int ERROR_DATA_INVALID_AAID = -1107;
    public static final int ERROR_DATA_INVALID_TLS_CERT = -1108;
    public static final int ERROR_DATA_INVALID_NIDCN_AAID = -1109;
    public static final int ERROR_DATA_INVALID_ENC_NIDCN = -1110;
    public static final int ERROR_DATA_INVALID_COMPATIBLE_TYPE = -1111;
    public static final int ERROR_DATA_INVALID_PKG_ID = -1112;

    public static final int ERROR_FIDO_USER_CANCELED = -1203;
    public static final int ERROR_FIDO_UNSUPPORTED_VERSION = -1204;
    public static final int ERROR_FIDO_NO_SUITABLE_AUTHENTICATOR = -1205;
    public static final int ERROR_FIDO_UNSTRUSTED_FACET_ID = -1207;
    public static final int ERROR_FIDO_INVALID_MESSAGE = -1250;
    public static final int ERROR_FIDO_PARSE_AAID = -1252;
    public static final int ERROR_FIDO_NOT_VALID_RESPONSE = -1270;
    public static final int ERROR_FIDO_UNKNOWN = -1290;

    public static final int ERROR_CRYPTO_GENERATE_KEYPAIR = -1301;
    public static final int ERROR_CRYPTO_GENERATE_NIDCT = -1302;

    public static final int ERROR_DATABASE_DELETE = -1401;
    public static final int ERROR_DATABASE_READ = -1402;

    public static final int ERROR_DEVICE_ROOTING = -1501;

    public static final int ERROR_COMPATIBLE_CANCELED = -1601;
    public static final int ERROR_COMPATIBLE_FAIL = -1602;
    public static final int ERROR_COMPATIBLE_DISALLOWED_APP = -1603;
    public static final int ERROR_COMPATIBLE_INVALID_FIDO_MESSAGE = -1604;
    public static final int ERROR_COMPATIBLE_INVALID_AUTH_RESULT = -1605;

    public String getMessageForException(Throwable throwable) {
        if(throwable instanceof MessageServiceException)
            return "바이오 공동앱과의 통신 중에 System 오류가 발생했습니다.";
        else if(throwable instanceof DeviceException)
            return "디바이스 정보 획득 중 오류가 발생했습니다.";
        else if(throwable instanceof EncryptionException)
            return "프로세스 수행중 암복호화 오류가 발생했습니다.";
        else if(throwable instanceof InvalidParameterException)
            return "잘못된 파라메터값이 입력되었습니다.";
        else if(throwable instanceof LnkAppException)
            return messageForLnkAppException((LnkAppException)throwable);
        if(throwable instanceof ServerException)
            return ((ServerException)throwable).getMessage();
        if(throwable instanceof NetworkException || throwable instanceof SocketTimeoutException)
            return "서버와 통신 중에 오류가 발생했습니다. (" + throwable.getMessage() + ")";
        return "오류가 발생했습니다.";
    }

    private String messageForLnkAppException(LnkAppException lnkAppException) {
        int code = Integer.valueOf(lnkAppException.getMessage());
        switch(code) {
            case ERROR_DATA_INVALID_CODE :
                return "잘못된 요청코드가 전달되었습니다.";
            case ERROR_DATA_INVALID_FIDO_MESSAGE :
                return "잘못된 FIDO메세지가 전달되었습니다.";
            case ERROR_DATA_INVALID_CHANNEL_BINDING :
                return "잘못된 채널바인딩값이 전달되었습니다.";
            case ERROR_FIDO_USER_CANCELED :
                return "사용자에 의해 요청이 취소되었습니다.(-1203)";
            default :
                return "바이오인증 수행중 오류가 발생하였습니다.("+code+")";
        }
    }
}