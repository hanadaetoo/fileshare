package kr.or.kftc.fido.common.util;

import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Created by shchoi on 2017-03-28.
 */

public class LogManager {
    private static final String TAG = "kr.or.kftc.fido";

    public static void info(String log) {
        Log.i(TAG, log);
    }

    public static void warn(String log) {
        Log.w(TAG, log);
    }

    public static void error(String log) {
        Log.e(TAG, log);
    }

    public static void error(Throwable e) {
        StringWriter writer = new StringWriter();
        e.printStackTrace(new PrintWriter(writer));
        Log.e(TAG, writer.toString());
    }
}