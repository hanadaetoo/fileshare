package kr.or.kftc.fido.common.exception.domain;

/**
 * Created by shchoi on 2017-03-07.
 */

public class InvalidLengthException extends InvalidParameterException {
    public static final int TYPE_LENGTH = 1;
    public static final int TYPE_MAX = 2;
    public static final int TYPE_MIN = 3;

    private String postFix;

    public InvalidLengthException(int type, String message) {
        super(message);
        this.postFix = postFixWithType(type);
    }

    @Override
    public String getMessage() {
        return super.getMessage() + postFix;
    }

    public String postFixWithType(int type) {
        switch(type) {
            case TYPE_LENGTH :
                return " has invalid length";
            case TYPE_MAX :
                return " has too much";
            case TYPE_MIN :
                return " should has more";
            default :
                return "";
        }
    }
}
