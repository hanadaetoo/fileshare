package kr.or.kftc.fido.common.domain.app;

import java.lang.reflect.Field;

import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;
import kr.or.kftc.fido.common.util.StringUtil;

/**
 * Created by shchoi on 2017-03-28.
 */

public abstract class ApplicationTransaction {
    protected int code;

    public ApplicationTransaction(int code) {
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }

    protected void checkFields() throws InvalidParameterException, IllegalAccessException {
        for(Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            StringUtil.checkStringField(field, String.valueOf(field.get(this)));
        }
    }
}
