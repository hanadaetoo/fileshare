package kr.or.kftc.fido.common.communicate.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;

import kr.or.kftc.fido.common.CommonConstant;
import kr.or.kftc.fido.common.exception.system.EncryptionException;
import kr.or.kftc.fido.common.exception.system.MessageServiceException;
import kr.or.kftc.fido.common.util.CryptoUtil;
import kr.or.kftc.fido.common.util.LogManager;

/**
 * Created by shchoi on 2017-03-27.
 */
public class MessageService extends Service {
    public static final String EXTRA_TARGET_PACKAGE = "EXTRA_TARGET_PACKAGE";

    final Messenger lnkMessenger = new Messenger(new LnkAppMessageHandler());
    ServiceConnection serviceConnection;
    Bundle sendBundle;

    static MessageCallback messageCallback;
    static MessageHandlePolicy messageHandlePolicy;

    public MessageService() {
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                try {
                    if(sendBundle == null) {
                        LogManager.error("[MessageService] sendBundle is null");
                        if(messageCallback != null)
                            messageCallback.onException(new MessageServiceException("sendBundle"));
                        return;
                    }

                    Message message = new Message();
                    message.setData(appendSecureAuthentication(sendBundle));
                    new Messenger(iBinder).send(message);
                } catch(RemoteException e) {
                    LogManager.error(e);
                    if(messageCallback != null)
                        messageCallback.onException(new MessageServiceException("remoteException"));
                } catch(EncryptionException e) {
                    LogManager.error(e);
                    if(messageCallback != null)
                        messageCallback.onException(e);
                } finally {
                    unbindService(serviceConnection);
                }
            }
            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                if(messageCallback != null)
                    messageCallback.onException(new MessageServiceException("service disconnected"));
            }
        };
    }

    public static void registerCallback(MessageCallback callback) throws MessageServiceException {
        if(messageCallback != null || callback == null)
            throw new MessageServiceException("another callback is registered");
        messageCallback = callback;
    }

    public static void unregisterCallback() {
        messageCallback = null;
    }

    public static void registerPolicy(MessageHandlePolicy policy) {
        messageHandlePolicy = policy;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent != null) {
            sendBundle = intent.getExtras();
            LogManager.info("[MessageService] send RequestVO");
            for(String key : sendBundle.keySet())
                LogManager.info("[MessageService] " + key + " : " + sendBundle.get(key));

            Intent sendIntent = new Intent(CommonConstant.SERVICE_NAME);
            sendIntent.setPackage(intent.getStringExtra(EXTRA_TARGET_PACKAGE));
            bindService(sendIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) {
        return lnkMessenger.getBinder();
    }

    public class LnkAppMessageHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            if(messageHandlePolicy != null && !messageHandlePolicy.onReceiveMessage(msg)) {
                LogManager.info("[MessageService] message excepted by policy");
                return;
            } else if(messageCallback == null) {
                LogManager.error("[MessageService] callback is null");
                return;
            }

            Bundle resultBundle = msg.getData();
            LogManager.info("[MessageService] receive responseVO of " + msg.what);
            for(String key : resultBundle.keySet())
                LogManager.info("[MessageService] " + key + " : " + resultBundle.get(key));

            if(msg.what == 0)
                msg.what = resultBundle.getInt(CommonConstant.KEY_CODE);
            messageCallback.onReceiveMessage(msg.what, msg.getData());
            unregisterCallback();
        }
    }

    private Bundle appendSecureAuthentication(Bundle bundle) throws EncryptionException {
        bundle.putString(CommonConstant.KEY_DEPATURE_PKG_ID,
                makeSecretPkgId(bundle.getInt(CommonConstant.KEY_CODE)));
        return bundle;
    }

    private String makeSecretPkgId(int code) throws EncryptionException {
        byte[] key = CryptoUtil.makeSymKey(getPackageName().getBytes(), 16);

        byte[] iv = {(byte) 0x21, (byte) 0x2E, (byte) 0xF1, (byte) 0x04, (byte) 0x27, (byte) 0x33,
                (byte) 0xDF, (byte) 0x9B, (byte) 0x21, (byte) 0x3A, (byte) 0xA0, (byte) 0x12,
                (byte) 0x3E, (byte) 0xAC, (byte) 0xA4, (byte) 0x7F};
        byte[] rnd = CryptoUtil.getRandom(10);

        byte[] c = new byte[2];
        c[0] = (byte) (code / 0x100);
        c[1] = (byte) (code % 0x100);

        byte[] input = new byte[rnd.length + c.length];
        System.arraycopy(rnd, 0, input, 0, rnd.length);
        System.arraycopy(c, 0, input, rnd.length, c.length);

        byte[] enc = CryptoUtil.aesEncrypt(key, iv, input);
        return CryptoUtil.hexEncode(enc);
    }
}