package kr.or.kftc.fido.common.exception.system;

/**
 * Created by shchoi on 2017-03-28.
 */

public class MessageServiceException extends Exception {

    public MessageServiceException(String s) {
        super(s);
    }

}
