package kr.or.kftc.fido.common.exception.system;

/**
 * Created by shchoi on 2017-03-30.
 */

public class EncryptionException extends Exception {

    public EncryptionException(String message) {
        super(message);
    }

}
