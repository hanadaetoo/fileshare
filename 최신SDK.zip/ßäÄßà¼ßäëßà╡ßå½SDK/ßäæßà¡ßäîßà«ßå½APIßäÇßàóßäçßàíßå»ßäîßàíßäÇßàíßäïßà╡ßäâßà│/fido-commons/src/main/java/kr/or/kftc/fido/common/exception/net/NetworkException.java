package kr.or.kftc.fido.common.exception.net;

/**
 * Created by shchoi on 2017-04-04.
 */

public class NetworkException extends Exception {

    public NetworkException(String message) {
        super(message);
    }
}
