package kr.or.kftc.fido.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kr.or.kftc.fido.common.exception.system.EncryptionException;

/**
 * Created by KFTC on 2016-10-05.
 *
 * 암호화 관련 클래스
 */
public class CryptoUtil {
    // AES 암호화
    public static byte[] aesEncrypt(byte[] key, byte[] iv, byte[] plain) throws EncryptionException {
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

            Cipher cipher = Cipher.getInstance("AES/CBC/Pkcs5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
            return cipher.doFinal(plain);
        } catch (NoSuchPaddingException e) {
            throw new EncryptionException("AES Encryption Fail : " + e.getMessage());
        } catch (Exception e) {
            throw new EncryptionException("AES Encryption Fail : " + e.getMessage());
        }
    }

    // 암호화용 키 생성
    public static byte[] makeSymKey(byte[] src, int length) throws EncryptionException {
        byte[] hash = sha1(src);

        byte[] output = null;
        if(length < hash.length) {
            output = new byte[length];
        }else {
            output = new byte[hash.length];
        }

        System.arraycopy(hash, 0, output, 0, output.length);
        return output;
    }

    //난수 생성
    public static byte[] getRandom(int length) {
        byte[] output = new byte[length];

        Random random = new Random();
        random.nextBytes(output);

        return output;
    }

    //SHA1 해시 알고리즘
    public static byte[] sha1(byte[] input) throws EncryptionException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            return md.digest(input);
        } catch (NoSuchAlgorithmException e) {
            throw new EncryptionException("SHA1 Fail");
        }
    }

    //SHA256 해시 알고리즘(스트링변환)
    public static byte[] sha256(String input) throws EncryptionException {
        return sha256(input.getBytes());
    }

    //SHA256 해시 알고리즘
    public static byte[] sha256(byte[] input) throws EncryptionException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(input);
        } catch (NoSuchAlgorithmException e) {
            throw new EncryptionException("SHA-256 Fail");
        }
    }

    //헥사인코딩
    public static String hexEncode(byte[] input) {
        int length = input.length;
        int line = length / 16, i, j;
        StringBuffer out = new StringBuffer(256);

        for (i = 0; i <= line; i++) {
            StringBuffer d = new StringBuffer(83);
            int column = Math.min(16, (length - i*16));

            for (j = 0; j < column; j++)  {
                char hi = Character.forDigit ((input[i*16+j] >> 4) & 0x0F, 16);
                char lo = Character.forDigit (input[i*16+j] & 0x0F, 16);

                d.append(Character.toUpperCase(hi));
                d.append(Character.toUpperCase(lo));
            }
            out.append(d.toString());
        }
        return out.toString();
    }
}
