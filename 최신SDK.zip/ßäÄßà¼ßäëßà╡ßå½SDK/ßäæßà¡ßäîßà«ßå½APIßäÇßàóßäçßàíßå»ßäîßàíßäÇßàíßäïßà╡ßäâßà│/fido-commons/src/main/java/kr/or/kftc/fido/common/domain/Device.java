package kr.or.kftc.fido.common.domain;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.StringTokenizer;

import kr.or.kftc.fido.common.CommonConstant;
import kr.or.kftc.fido.common.exception.system.DeviceException;
import kr.or.kftc.fido.common.exception.system.EncryptionException;
import kr.or.kftc.fido.common.util.CryptoUtil;
import kr.or.kftc.fido.common.util.LogManager;

/**
 * Created by shchoi on 2017-03-28.
 */

public class Device extends CommonConstant {
    private final String samsungFidoClientPackage = "com.sec.android.fido.uaf.client";
    private final String samsungNewFidoClientPackage = "com.samsung.android.authfw";
    private final String lgFidoClientPackage = "com.crucialsoft.fido.client";
    private final Context context;

    public Device(Context context) {
        this.context = context;
    }

    public String getUUID() throws DeviceException, EncryptionException {
        String uuid = CryptoUtil.hexEncode(CryptoUtil.sha256(getAndroidId()+getSerialNo()));
        LogManager.info("[Device] UUID created by AndroidID["+getAndroidId()+"] serialNo["+getSerialNo()+"]");
        LogManager.info("[Device] UUID ["+uuid+"]");
        return uuid;
    }

    public String getAndroidId() {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public String getSerialNo() throws DeviceException {
        try {
            Class<?> mClass = Class.forName("android.os.SystemProperties");
            Method method = mClass.getMethod("get", String.class);
            return (String) method.invoke(mClass, "ro.serialno");
        } catch(ClassNotFoundException e) {
            LogManager.error(e);
            throw new DeviceException(e.getClass().getName());
        } catch(NoSuchMethodException e) {
            LogManager.error(e);
            throw new DeviceException(e.getClass().getName());
        } catch(IllegalAccessException e) {
            LogManager.error(e);
            throw new DeviceException(e.getClass().getName());
        } catch(InvocationTargetException e) {
            LogManager.error(e);
            throw new DeviceException(e.getClass().getName());
        }
    }

    public boolean checkLinkAppInstalled() throws DeviceException {
        if(context == null) {
            throw new DeviceException("Context is null");
        }

        try {
            context.getPackageManager().getPackageInfo("org.kftc.fido.lnk.lnk_app",
                    PackageManager.GET_ACTIVITIES);
            return true;
        } catch(PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static boolean isAvailableLnkAppVersion(String lnkAppVersion, String serverVersion)
    throws NumberFormatException {
        if(lnkAppVersion == null || lnkAppVersion.length() != 4)
            return false;
        else if(serverVersion == null || serverVersion.length() != 8)
            return false;
        int lnkAppVersionInt = Integer.valueOf(lnkAppVersion);
        int serverMinVersionInt = Integer.valueOf(serverVersion.substring(4, 8));

        if(lnkAppVersionInt >= serverMinVersionInt)
            return true;
        return false;
    }

    public static boolean isRecentLnkAppVersion(String lnkAppVersion, String serverVersion)
            throws NumberFormatException {
        if(lnkAppVersion == null || lnkAppVersion.length() != 4)
            return false;
        else if(serverVersion == null || serverVersion.length() != 8)
            return false;
        int lnkAppVersionInt = Integer.valueOf(lnkAppVersion);
        int serverRecentVersionInt = Integer.valueOf(serverVersion.substring(0, 4));

        if(lnkAppVersionInt == serverRecentVersionInt)
            return true;
        return false;
    }

    public boolean isSamsungFidoClient() {
        Intent intent = new Intent("org.fidoalliance.intent.FIDO_OPERATION");
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setType("application/fido.uaf_client+json");

        for(ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(
                intent, PackageManager.GET_META_DATA)) {
            String tmpPackage = resolveInfo.activityInfo.packageName;
            if (tmpPackage.equalsIgnoreCase(samsungFidoClientPackage))
                return true;
        }
        return false;
    }

//    S8 버전 문제로 인해 FIDO Client 체크로직 변경
//    public Intent getFidoClientCheckIntent() throws DeviceException {
//        Intent intent = new Intent("org.fidoalliance.intent.FIDO_OPERATION");
//        intent.addCategory("android.intent.category.DEFAULT");
//        intent.setType("application/fido.uaf_client+json");
//        intent.putExtra("UAFIntentType", "DISCOVER");
//        ComponentName fidoClientComponentName = getFidoClientComponentName();
//        if("".equals(fidoClientComponentName.getPackageName()))
//            throw new DeviceException("no authorized fido client detected");
//        intent.setComponent(fidoClientComponentName);
//        return intent;
//    }

    public ComponentName getFidoClientComponentName() {
        String namePackage = "";
        String nameActivity = "";

        Intent intent = new Intent("org.fidoalliance.intent.FIDO_OPERATION");
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setType("application/fido.uaf_client+json");

        for(ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(
                intent, PackageManager.GET_META_DATA)) {
            String tmpPackage = resolveInfo.activityInfo.packageName;
            System.out.println("Package Name : "+tmpPackage);
            if(tmpPackage.equalsIgnoreCase(samsungFidoClientPackage)) {
                namePackage = tmpPackage;
                nameActivity = resolveInfo.activityInfo.name;
                break;
            }else if(tmpPackage.equalsIgnoreCase(samsungNewFidoClientPackage)) {
                namePackage = tmpPackage;
                nameActivity = resolveInfo.activityInfo.name;
                break;
            }else if(tmpPackage.equalsIgnoreCase(lgFidoClientPackage)) {
                namePackage = tmpPackage;
                nameActivity = resolveInfo.activityInfo.name;
                break;
            }
        }

//        if(nameActivity == null || namePackage.isEmpty()) {
//            return null;
//        }

        return new ComponentName(namePackage, nameActivity);
    }

    public boolean checkSamsungFidoClientNeedUpdate() throws DeviceException {
        if(context == null) {
            throw new DeviceException("Context is null");
        }

        PackageManager pm = context.getPackageManager();
        List<PackageInfo> packs = pm.getInstalledPackages(PackageManager.PERMISSION_GRANTED);
        for (PackageInfo pack : packs) {
            if(pack.packageName.equalsIgnoreCase(samsungFidoClientPackage) ) {
                String targetVersion = "15.0.88";
                StringTokenizer checkVersionToken = new StringTokenizer(pack.versionName, ".");
                int checkVersionCount = checkVersionToken.countTokens();

                StringTokenizer targetVersionToken = new StringTokenizer(targetVersion, ".");
                int targetVersionCount = targetVersionToken.countTokens();

                int count = 0;
                if(checkVersionCount > targetVersionCount)
                    count = targetVersionCount;
                else
                    count = checkVersionCount;

                int i = 0;
                for(i=0; i<count; i++) {
                    int check  = Integer.parseInt(checkVersionToken.nextToken());
                    int target = Integer.parseInt(targetVersionToken.nextToken());
                    if(check > target)
                        return false;
                    else if(check < target)
                        return true;
                }
                return false;
            }
        }
        throw new DeviceException("Samsung FIDO client does not exist");
    }

    //지문 지원 확인
    public static int checkFingerPrint(Context context) {
        int ret = FINGERPRINT_NO_PERMISSION;

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            // Has no permissions

            return FINGERPRINT_NO_PERMISSION;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            FingerprintManager fingerprintManager = (FingerprintManager) context.getSystemService(Context.FINGERPRINT_SERVICE);

            if (!fingerprintManager.isHardwareDetected()) {
                // Device doesn't support fingerprint authentication
                return FINGERPRINT_NOT_SUPPORT;
            } else if (!fingerprintManager.hasEnrolledFingerprints()) {
                // User hasn't enrolled any fingerprints to authenticate with
                return FINGERPRINT_NO_ENROLLED;
            } else {
                // Everything is ready for fingerprint authentication
                return FINGERPRINT_READY;
            }

        }else{
            return FINGERPRINT_NOT_SUPPORT;
        }
    }
}