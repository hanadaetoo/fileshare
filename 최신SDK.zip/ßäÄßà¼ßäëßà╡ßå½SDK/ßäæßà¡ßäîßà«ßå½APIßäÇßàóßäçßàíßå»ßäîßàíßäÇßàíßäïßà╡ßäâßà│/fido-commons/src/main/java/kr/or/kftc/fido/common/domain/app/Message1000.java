package kr.or.kftc.fido.common.domain.app;

import android.os.Bundle;

import kr.or.kftc.fido.common.CommonConstant;
import kr.or.kftc.fido.common.di.StringField;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;

/**
 * Created by shchoi on 2017-03-28.
 */

public class Message1000 extends ApplicationTransaction implements ApplicationResponse {
    @StringField(type = "ANS", length = 5) String errorCode;
    @StringField(type = "ANS") String failCount;

    public Message1000(int code) throws InvalidParameterException {
        super(1000);

        try {
            checkFields();
        } catch(IllegalAccessException e) {
            throw new InvalidParameterException(e.getClass().getName() + " "
                    + this.getClass().getName());
        }
    }

    public Message1000(Bundle bundle) throws InvalidParameterException {
        super(1000);
        fromBundle(bundle);

        try {
            checkFields();
        } catch(IllegalAccessException e) {
            throw new InvalidParameterException(e.getClass().getName() + " "
                    + this.getClass().getName());
        }
    }

    public int getErrorCode() {
        return Integer.valueOf(this.errorCode);
    }

    public int getFailCount() {
        return Integer.valueOf(this.failCount);
    }

    @Override
    public void fromBundle(Bundle bundle) {
        errorCode = bundle.getString(CommonConstant.KEY_ERROR_CODE);
        failCount = bundle.getString(CommonConstant.DATA_KEY_AUTH_FAIL_COUNT);
    }
}