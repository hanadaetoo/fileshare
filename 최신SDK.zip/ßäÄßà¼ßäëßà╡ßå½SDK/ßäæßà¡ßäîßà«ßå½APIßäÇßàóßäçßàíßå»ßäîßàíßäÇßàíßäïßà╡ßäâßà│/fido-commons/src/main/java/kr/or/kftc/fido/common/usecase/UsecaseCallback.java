package kr.or.kftc.fido.common.usecase;

/**
 * Created by shchoi on 2017-04-04.
 */

public interface UsecaseCallback {

    void onSuccess(Object... result);

    void onFailure(String errorMessage);
}
