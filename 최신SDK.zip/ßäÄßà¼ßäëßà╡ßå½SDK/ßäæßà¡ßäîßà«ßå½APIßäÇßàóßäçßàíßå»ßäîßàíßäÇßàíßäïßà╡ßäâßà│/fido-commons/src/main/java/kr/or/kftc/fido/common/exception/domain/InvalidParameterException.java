package kr.or.kftc.fido.common.exception.domain;

/**
 * 통신을 위한 메세지 조립/분할 중 발생하는 오류
 */
public class InvalidParameterException extends Exception {
    public InvalidParameterException(String message) {
        super(message);
    }
}
