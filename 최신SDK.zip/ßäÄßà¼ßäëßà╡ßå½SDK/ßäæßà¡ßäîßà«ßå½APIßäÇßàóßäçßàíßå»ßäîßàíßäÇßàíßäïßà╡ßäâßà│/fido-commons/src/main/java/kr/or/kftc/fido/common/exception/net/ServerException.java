package kr.or.kftc.fido.common.exception.net;

/**
 * 서버의 오류 상태를 나타내기 위한 Exception 클래스.
 * 테스트를 위한 금융결제원의 BankWebServer는 AP의 오류코드를 그대로 반환하므로,
 * 참가기관에서는 해당하는 오류를 서버에서 처리하여야 한다.
 */
public class ServerException extends Exception {
    private int code;

    public ServerException(int code) {
        this.code = code;
    }

    public ServerException(String code) {
        this.code = Integer.valueOf(code);
    }

    @Override
    public String getMessage() {
        switch (code) {
            case 1000 :
                return "기관의 바이오정보 분산관리시스템 개인매체방식 서버가 개시되지 않았습니다.(1000)";
            case 1001 :
                return "기관의 바이오정보 분산관리시스템 개인매체방식 서버가 이미 개시된 상태입니다.(1001)";
            case 1002 :
                return "요청에 대한 처리 담당이 지정되지 않았습니다.(1002)";
            case 1003 :
                return "요청된 전문이 너무 많습니다.(1003)";
            case 1004 :
                return "일시적인 오류로 서비스가 불가능한 상태입니다.(1004)";
            case 1005 :
            case 5000 :
                return "중복된 전문입니다.("+code+")";
            case 1999 :
                return "서버에서의 처리가 지연되었습니다.(1999)";
            case 5003 :
                return "비식별호환번호가 일치하지 않습니다.(5003)";
            case 5005 :
                return "단말의 운영체제를 확인해주세요.(5005)";
            case 5007 :
                return "등록방식코드를 확인해주세요.(5007)";
            case 5009 :
                return "등록되지 않은 AAID 입니다. (금융결제원 문의 요망)(5009)";
            case 5010 :
                return "비식별호환토큰을 확인해주세요.(5010)";
            case 5102 :
                return "선행 전무을 찾을 수 없습니다.(5102)";
            case 5107 :
                return "비식별호환토큰 검증을 실패하였습니다.(5107)";
            case 5109 :
                return "호환인증을 지원하지 않는 기관입니다.(5109)";
            case 5111 :
                return "등록되지 않은 등록여부조회키 입니다.(5111)";
            case 5112 :
                return "거래구분코드를 확인해주세요.(5112)";
            case 5113 :
                return "등록되지 않은 단말아이디 입니다.(5113)";
            case 5114 :
                return "등록되지 않은 참가기관 입니다.(5114)";
            case 5115 :
                return "등록되지 않은 서비스코드 입니다.(5115)";
            case 5120 :
                return "등록된 방식과 다른 방식의 요청입니다.(5120)";
            case 5121 :
                return "FIDO인증이 실패 혹은 취소되었습니다.(5121)";
            case 5122 :
                return "싱글매치 정책을 위반한 바이오정보 입니다.(5122)";
            case 5203 :
                return "인증타입 검증 중 오류가 발생했습니다.(5203)";
            case 5204 :
                return "거래타입 검증 중 오류가 발생했습니다.(5204)";
            case 5206 :
                return "선행전문과 참가기관코드가 일치하지 않습니다.(5206)";
            case 5210 :
                return "비식별호환번호 조회 중 오류가 발생했습니다.(5210)";
            case 5214 :
                return "호환인증 기관정보를 확인해주세요.(5214)";
            case 5215 :
                return "호환인증 서비스 정보를 확인해주세요.(5215)";
            case 5217 :
                return "호환인증 요청 정보를 확인해주세요.(5217)";
            case 5218 :
                return "거래내역존재를 확인해주세요.(5218)";
            case 5401 :
                return "연속인증실패횟수를 초과한 바이오 정보입니다.(5401)";
            default :
                return "서버와의 통신 중에 오류가 발생했습니다.(" + code + ")";
        }
    }
}
