package kr.or.kftc.fido.common.util;

import java.lang.reflect.Field;
import java.util.regex.Pattern;

import kr.or.kftc.fido.common.di.StringField;
import kr.or.kftc.fido.common.exception.domain.InvalidLengthException;
import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;
import kr.or.kftc.fido.common.exception.domain.InvalidTypeException;

/**
 * Created by shchoi on 2017-03-07.
 */

public class StringUtil {
    private final static Pattern patternAlpha = Pattern.compile("[A-Za-z]*");
    private final static Pattern patternNum = Pattern.compile("[0-9]*");
    private final static Pattern patternAlphaNum = Pattern.compile("[A-Za-z0-9]*");
    private final static Pattern patternAlphaNumSpecial = Pattern.compile("[A-za-z0-9|+#-_{}.,\"\\\\]*");

    public static String getValidString(String target) {
        if(target == null)
            return "";
        return target;
    }

    public static String checkStringField(Field field, String value) throws InvalidParameterException {
        if(field.isAnnotationPresent(StringField.class)) {
            StringField annotation = field.getAnnotation(StringField.class);
            if(annotation.nullCheck() && value == null)
                throw new IllegalArgumentException(field.getName());
            value = getValidString(value);

            if("A".equals(annotation.type()) && !isAlpha(value))
                throw new InvalidTypeException("A", field.getName());
            else if("N".equals(annotation.type()) && !isNumeric(value))
                throw new InvalidTypeException("N", field.getName());
            else if("AN".equals(annotation.type()) && !isAlphaNumeric(value))
                throw new InvalidTypeException("AN", field.getName());
            else if("ANS".equals(annotation.type()) && !isAlphaNumericSpecial(value))
                throw new InvalidTypeException("ANS", field.getName());

            int valueLength = value.length();
            int definedLength = annotation.length();
            if(definedLength != 0 && valueLength != definedLength)
                throw new InvalidLengthException(InvalidLengthException.TYPE_LENGTH, field.getName());

            int definedMaxLength = annotation.maxLength();
            if(definedMaxLength != 0 && valueLength > definedMaxLength)
                throw new InvalidLengthException(InvalidLengthException.TYPE_MAX, field.getName());

            int definedMinLength = annotation.minLength();
            if(definedMinLength != 0 && valueLength < definedMinLength)
                throw new InvalidLengthException(InvalidLengthException.TYPE_MIN, field.getName());
        }

        return value;
    }

    private static boolean isAlpha(String target) {
        if(target == null)
            return false;
        else if(!patternAlpha.matcher(target).matches())
            return false;
        return true;
    }

    private static boolean isNumeric(String target) {
        if(target == null)
            return false;
        else if(!patternNum.matcher(target).matches())
            return false;
        return true;
    }

    private static boolean isAlphaNumeric(String target) {
        if(target == null)
            return false;
        else if(!patternAlphaNum.matcher(target).matches())
            return false;
        return true;
    }

    private static boolean isAlphaNumericSpecial(String target) {
        if(target == null)
            return false;
        else if(!patternAlphaNumSpecial.matcher(target).matches())
            return false;
        return true;
    }
}