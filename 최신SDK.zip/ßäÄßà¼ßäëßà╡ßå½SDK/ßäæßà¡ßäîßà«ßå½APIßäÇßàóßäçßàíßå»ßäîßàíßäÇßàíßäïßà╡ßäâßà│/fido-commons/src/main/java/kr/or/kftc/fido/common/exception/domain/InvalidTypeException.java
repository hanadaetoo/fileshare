package kr.or.kftc.fido.common.exception.domain;

/**
 * Created by shchoi on 2017-03-07.
 */

public class InvalidTypeException extends InvalidParameterException {

    private String type;

    public InvalidTypeException(String type, String message) {
        super(message);
        this.type = type;
    }

    @Override
    public String getMessage() {
        return super.getMessage() + " is not type " + type;
    }
}
