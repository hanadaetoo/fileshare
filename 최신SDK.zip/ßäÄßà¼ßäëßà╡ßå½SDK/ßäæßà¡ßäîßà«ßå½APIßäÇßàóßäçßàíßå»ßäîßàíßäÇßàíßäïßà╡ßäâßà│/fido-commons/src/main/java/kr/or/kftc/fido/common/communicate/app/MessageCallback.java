package kr.or.kftc.fido.common.communicate.app;

import android.os.Bundle;

/**
 * Created by shchoi on 2017-03-28.
 */

public interface MessageCallback {

    void onReceiveMessage(int code, Bundle bundle);

    void onException(Throwable throwable);
}
