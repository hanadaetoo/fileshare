package kr.or.kftc.fido.common.exception;

import kr.or.kftc.fido.common.domain.app.Message1000;

/**
 * Created by shchoi on 2017-04-03.
 */

public class LnkAppException extends Exception {
    public LnkAppException(Message1000 message1000) {
        super(String.valueOf(message1000.getErrorCode()));
    }
}
