package kr.or.kftc.fido.common;

/**
 * Created by shchoi on 2017-03-28.
 */

public class CommonConstant {
    public static final String SERVICE_NAME = "org.kftc.fido.finance.service";

    public static final String KEY_CODE = "DATA_KEY_CODE";
    public static final String KEY_ERROR_CODE = "DATA_KEY_ERROR_CODE";
    public static final String DATA_KEY_AUTH_FAIL_COUNT = "DATA_KEY_AUTH_FAIL_COUNT";
    public static final String KEY_BUNDLE = "DATA_KEY_BUNDLE";
    public static final String KEY_DEPATURE_PKG_ID = "DATA_KEY_DEPARTURE_PKG_ID";

    public static final String KEY_NIDCN_LIST = "DATA_KEY_NIDCN_LIST";
    public static final String KEY_VERSION = "DATA_KEY_VERSION";
    public static final String KEY_PKG_ID = "DATA_KEY_PKG_ID";
    public static final String KEY_NIDCN_AAID = "DATA_KEY_NIDCN_AAID";
    public static final String KEY_NIDCT = "DATA_KEY_NIDCT";
    public static final String KEY_NIDCT_CHALLENGE = "DATA_KEY_NIDCT_CHALLENGE";
    public static final String KEY_FIDO = "DATA_KEY_FIDO";
    public static final String KEY_FIDO_AUTH_RESULT = "DATA_KEY_FIDO_AUTH_RESULT";
    public static final String KEY_PUB_KEY = "DATA_KEY_PUBKEY";
    public static final String KEY_PRV_KEY = "DATA_KEY_PRIVKEY";
    public static final String KEY_ENC_NIDCN = "DATA_KEY_ENC_NIDCN";
    public static final String KEY_COMPATIBLE = "DATA_KEY_COMPATIBLE";
    public static final String KEY_NIDCN_SAVE_RESULT = "DATA_KEY_SAVE_NIDCN_RESULT";
    public static final String KEY_TLS_CERT = "DATA_KEY_TLS_CERT";
    public static final String KEY_SITE_CODE = "DATA_KEY_SITE_CODE";
    public static final String KEY_SVC_CODE = "DATA_KEY_SVC_CODE";
    public static final String KEY_NEED_KEY = "DATA_KEY_NEED_KEY";
    public static final String KEY_DEVICE_ID = "DATA_KEY_DEVICE_ID";
    public static final String KEY_AUTH_TECH_LIST = "DATA_KEY_AUTH_TECH_LIST";
    public static final String KEY_DEREG_RESULT = "DATA_KEY_DEREG_RESULT";
    public static final String KEY_AAID = "DATA_KEY_AAID";
    public static final String KEY_DEL_NIDCN_REUSLT = "DATA_KEY_DEL_NIDCN_REUSLT";

    public static final String TRAN_TYPE_AUTH = "0";
    public static final String TRAN_TYPE_SIGN = "1";
    public static final String TRAN_TYPE_SIGN_WITHOUT_TRADE_DATA = "2";

    public static final String AUTH_TECH_FINGERPRINT = "100";
    public static final String AUTH_TECH_IRIS = "104";
    public static final String AUTH_TECH_MIXED = "199";

    /*
    * 지문장치 확인 결과
    */
    public static final int FINGERPRINT_READY = 0;
    public static final int FINGERPRINT_NOT_SUPPORT = 1;
    public static final int FINGERPRINT_NO_ENROLLED = 2;
    public static final int FINGERPRINT_NO_PERMISSION = -1;

}
