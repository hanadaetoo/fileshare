package kr.or.kftc.fido.common.di;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by shchoi on 2017-03-28.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface StringField {
    // supported type : A, N, AN
    String type() default "";
    boolean nullCheck() default false;

    int length() default 0;
    int maxLength() default 0;
    int minLength() default 0;
}
