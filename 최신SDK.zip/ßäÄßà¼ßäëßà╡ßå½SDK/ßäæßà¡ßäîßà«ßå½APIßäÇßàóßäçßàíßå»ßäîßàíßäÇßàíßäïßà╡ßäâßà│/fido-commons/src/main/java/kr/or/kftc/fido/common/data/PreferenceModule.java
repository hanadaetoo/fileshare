package kr.or.kftc.fido.common.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by shchoi on 2017-04-06.
 */

public class PreferenceModule {
    private final SharedPreferences preferences;

    public PreferenceModule(Context context, String preferenceID) {
        this.preferences = context.getSharedPreferences(preferenceID, Context.MODE_PRIVATE);
    }

    public String readString(String key) {
        return preferences.getString(key, "");
    }

    public Boolean readBoolean(String key) {
        return preferences.getBoolean(key, false);
    }

    public boolean writeString(String key, String value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        return editor.commit();
    }

    public boolean writeBoolean(String key, Boolean value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(key, value);
        return editor.commit();
    }

    public boolean writeStringArray(String key, String[] values) {
        HashSet<String> set = new HashSet<>();
        Collections.addAll(set, values);

        SharedPreferences.Editor editor = preferences.edit();
        editor.putStringSet(key, set);
        return editor.commit();
    }

    public String[] readStringArray(String key) {
        Set<String> set = preferences.getStringSet(key, new HashSet<String>());

        String[] values = new String[set.size()];
        set.toArray(values);

        return values;
    }
}
