package kr.or.kftc.fido.common.domain.app;

import android.os.Bundle;

import kr.or.kftc.fido.common.exception.domain.InvalidParameterException;

/**
 * Created by shchoi on 2017-03-28.
 */

public interface ApplicationResponse {

    void fromBundle(Bundle bundle) throws InvalidParameterException;
}
