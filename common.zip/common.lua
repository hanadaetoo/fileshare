--============================================================================
-- split
--============================================================================
function split(str, pat)
   local t = {}
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
		 table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

--============================================================================
-- tonumber 재선언
--============================================================================
function _tonumber( szData )

	return not tonumber( szData ) and 0 or tonumber( szData )
end


--============================================================================
-- 한글처리 관련
--============================================================================
function chsize(char)
	if not char then
		return 0
	elseif char > 240 then
		return 4
	elseif char > 225 then
		return 3
	elseif char > 192 then
		return 2
	else
		return 1
	end
end

--한글 자르는 함수
function utf8sub(str, startChar, numChars)	--시작위치(1부터), 문자갯수
	local startIndex = 1
	while startChar > 1 do
		local char = string.byte(str, startIndex)
		startIndex = startIndex + chsize(char)
		startChar = startChar -1
	end

	local currentIndex = startIndex

	while numChars > 0 and currentIndex <= #str do
		local char = string.byte(str, currentIndex)
		currentIndex = currentIndex + chsize(char)
		numChars = numChars -1
	end

	return str:sub(startIndex, currentIndex - 1)
end

function utf8len(str)
	local currentIndex = 1
	local strLen = 0
	while currentIndex <= #str do
		local char = string.byte(str, currentIndex)
		if chsize(char) == 0 then
			break
		end
		currentIndex = currentIndex + chsize(char)
		strLen = strLen + 1
	end

	return strLen
end



--[[=======================
-- url 디코딩
--=======================]]
--url 디코딩 테이블
local common_hex_table = {}

function decodeURI(s)
	return (string.gsub(s, '%%(%x%x)',common_hex_table))
end

--url 디코딩 테이블 초기화
for i=0,255 do
	common_hex_table[string.format("%0x", i)]=string.char(i)
	common_hex_table[string.format("%0X", i)]=string.char(i)
end
common_hex_table["0A"] = "\n"
common_hex_table["0a"] = "\n"

